-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: crop_alert_system
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alert_farmers`
--

DROP TABLE IF EXISTS `alert_farmers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_farmers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alert_id` int(11) NOT NULL,
  `farmer_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_alert_farmer` (`alert_id`,`farmer_id`),
  KEY `idx_alert_farmers_alert_id` (`alert_id`),
  KEY `idx_alert_farmers_farmer_id` (`farmer_id`),
  KEY `idx_alert_farmers_created_at` (`created_at`),
  CONSTRAINT `alert_farmers_ibfk_1` FOREIGN KEY (`alert_id`) REFERENCES `alerts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_alert_farmers_user` FOREIGN KEY (`farmer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_farmers`
--

LOCK TABLES `alert_farmers` WRITE;
/*!40000 ALTER TABLE `alert_farmers` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert_farmers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_statistics_aggregates`
--

DROP TABLE IF EXISTS `alert_statistics_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alert_statistics_aggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_date` date NOT NULL,
  `total_alerts` int(11) NOT NULL DEFAULT 0,
  `active_count` int(11) NOT NULL DEFAULT 0,
  `resolved_count` int(11) NOT NULL DEFAULT 0,
  `cancelled_count` int(11) NOT NULL DEFAULT 0,
  `type_distribution` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`type_distribution`)),
  `severity_distribution` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`severity_distribution`)),
  `affected_farmers_count` int(11) DEFAULT 0,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_date` (`aggregate_date`),
  KEY `idx_aggregate_date` (`aggregate_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_statistics_aggregates`
--

LOCK TABLES `alert_statistics_aggregates` WRITE;
/*!40000 ALTER TABLE `alert_statistics_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `alert_statistics_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `severity` enum('low','medium','high') NOT NULL DEFAULT 'medium',
  `description` text NOT NULL,
  `status` enum('active','resolved','cancelled') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `disaster_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_alerts_status` (`status`),
  KEY `idx_alerts_created_at` (`created_at`),
  KEY `idx_alerts_type` (`type`),
  KEY `idx_alerts_severity` (`severity`),
  KEY `idx_alerts_status_created_at` (`status`,`created_at`),
  KEY `idx_alerts_status_updated_at` (`status`,`updated_at`),
  KEY `idx_alerts_status_created` (`status`,`created_at`),
  KEY `idx_alerts_disaster_id` (`disaster_id`),
  KEY `idx_alerts_status_created_updated` (`status`,`created_at`,`updated_at`),
  KEY `idx_alerts_status_type_severity` (`status`,`type`,`severity`),
  KEY `idx_alerts_status_disaster` (`status`,`disaster_id`),
  KEY `idx_alerts_type_severity` (`type`,`severity`),
  FULLTEXT KEY `ft_idx_alerts_description` (`description`),
  CONSTRAINT `fk_alert_disaster` FOREIGN KEY (`disaster_id`) REFERENCES `disasters` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
INSERT INTO `alerts` VALUES (1,'Heavy Rainfall Warning','medium','Heavy rainfall detected. Monitor for flooding and drainage issues.','resolved','2025-11-08 07:57:29','2025-11-17 09:44:53',NULL),(2,'Drought Warning','high','Low rainfall detected for the past week. Consider irrigation and water conservation measures.','resolved','2025-11-08 07:57:29','2025-11-17 09:44:53',NULL),(3,'Storm Warning','high','High wind speed and heavy rainfall detected. Secure crops and equipment.','resolved','2025-11-08 07:57:29','2025-11-08 07:57:29',NULL),(4,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (62.2 km/h). Prepare in advance and secure your property.','resolved','2025-11-08 08:49:44','2025-11-17 09:44:53',NULL),(5,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (62.2 km/h). Prepare in advance and secure your property.','resolved','2025-11-08 08:50:07','2025-11-17 09:44:53',NULL),(6,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (62.2 km/h). Prepare in advance and secure your property.','resolved','2025-11-08 08:54:15','2025-11-17 09:44:53',NULL),(7,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (62.2 km/h). Prepare in advance and secure your property.','resolved','2025-11-08 08:54:21','2025-11-17 09:44:53',NULL),(8,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (62.2 km/h). Prepare in advance and secure your property.','resolved','2025-11-08 08:55:13','2025-11-17 09:44:53',NULL),(9,'typhoon','high','Typhoon-level winds expected on 2025-11-09 near Manila. Wind speed: 62.2 km/h, gusts up to 91.1 km/h. Precipitation: 40mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',2),(10,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-09 near Cebu. Wind speed: 48.2 km/h, gusts up to 67.7 km/h.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',3),(11,'typhoon','high','Typhoon-level winds expected on 2025-11-09 near Baguio. Wind speed: 30.8 km/h, gusts up to 121 km/h. Precipitation: 54.1mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',4),(12,'typhoon','high','Typhoon-level winds expected on 2025-11-09 near Naga. Wind speed: 56.7 km/h, gusts up to 126.4 km/h. Precipitation: 64.3mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',5),(13,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-09 near Tacloban. Wind speed: 22.4 km/h, gusts up to 55.8 km/h.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',6),(14,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-09 near Cagayan de Oro. Wind speed: 31.3 km/h, gusts up to 50.8 km/h.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',7),(15,'typhoon','high','Typhoon-level winds expected on 2025-11-09 near Angeles. Wind speed: 30.2 km/h, gusts up to 89.6 km/h. Precipitation: 14.6mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',8),(16,'typhoon','high','Typhoon-level winds expected on 2025-11-09 near Quezon City. Wind speed: 62.2 km/h, gusts up to 91.1 km/h. Precipitation: 40mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',9),(17,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-09 near Zamboanga. Wind speed: 35.2 km/h, gusts up to 52.6 km/h.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',10),(18,'typhoon','high','Typhoon-level winds expected on 2025-11-10 near Manila. Wind speed: 58.9 km/h, gusts up to 88.2 km/h. Precipitation: 44.5mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',11),(19,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-10 near Cebu. Wind speed: 41.1 km/h, gusts up to 56.5 km/h.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',12),(20,'typhoon','high','Typhoon-level winds expected on 2025-11-10 near Baguio. Wind speed: 33.1 km/h, gusts up to 119.9 km/h. Precipitation: 115.5mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',13),(21,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-10 near Naga. Wind speed: 29 km/h, gusts up to 68.4 km/h.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',14),(22,'typhoon','high','Typhoon-level winds expected on 2025-11-10 near Angeles. Wind speed: 34 km/h, gusts up to 102.2 km/h. Precipitation: 19.9mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',15),(23,'typhoon','high','Typhoon-level winds expected on 2025-11-10 near Quezon City. Wind speed: 58.9 km/h, gusts up to 88.2 km/h. Precipitation: 44.5mm.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',16),(24,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-11 near Manila. Wind speed: 46.2 km/h, gusts up to 66.2 km/h.','resolved','2025-11-08 09:23:22','2025-11-17 09:44:53',17),(25,'typhoon','high','Typhoon-level winds expected on 2025-11-11 near Baguio. Wind speed: 21.7 km/h, gusts up to 97.9 km/h. Precipitation: 20.8mm.','resolved','2025-11-08 09:23:23','2025-11-17 09:44:53',18),(26,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-11 near Angeles. Wind speed: 23.8 km/h, gusts up to 73.8 km/h.','resolved','2025-11-08 09:23:23','2025-11-17 09:44:53',19),(27,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-11 near Quezon City. Wind speed: 46.2 km/h, gusts up to 66.2 km/h.','resolved','2025-11-08 09:23:23','2025-11-17 09:44:53',20),(28,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (62.2 km/h). Prepare in advance and secure your property.','resolved','2025-11-08 09:34:44','2025-11-17 09:44:53',NULL),(29,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (62.2 km/h). Prepare in advance and secure your property.','resolved','2025-11-08 09:34:54','2025-11-17 09:44:53',NULL),(30,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (70.7 km/h). Prepare in advance and secure your property.','resolved','2025-11-09 03:22:23','2025-11-17 09:44:53',NULL),(31,'flood','medium','Heavy rainfall expected on 2025-11-10 (55.3mm). Prepare for potential flooding.','resolved','2025-11-09 03:22:23','2025-11-17 09:44:53',NULL),(32,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (70.7 km/h). Prepare in advance and secure your property.','resolved','2025-11-09 03:22:35','2025-11-17 09:44:53',NULL),(33,'flood','medium','Heavy rainfall expected on 2025-11-10 (55.3mm). Prepare for potential flooding.','resolved','2025-11-09 03:22:35','2025-11-17 09:44:53',NULL),(34,'typhoon','high','Typhoon-level winds expected on 2025-11-09 (70.7 km/h). Prepare in advance and secure your property.','resolved','2025-11-09 03:22:38','2025-11-17 09:44:53',NULL),(35,'flood','medium','Heavy rainfall expected on 2025-11-10 (55.3mm). Prepare for potential flooding.','resolved','2025-11-09 03:22:38','2025-11-17 09:44:53',NULL),(36,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-25 near Angeles. Wind speed: 11.5 km/h, gusts up to 54.7 km/h.','resolved','2025-11-20 02:33:40','2025-11-29 11:48:35',21),(37,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-26 near Angeles. Wind speed: 11.2 km/h, gusts up to 50.8 km/h.','resolved','2025-11-20 02:33:40','2025-11-29 11:48:35',22),(38,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-22 near Angeles. Wind speed: 15.7 km/h, gusts up to 61.6 km/h.','resolved','2025-11-22 07:43:22','2025-11-29 11:48:35',23),(39,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-23 near Angeles. Wind speed: 18.2 km/h, gusts up to 51.5 km/h.','resolved','2025-11-22 07:43:22','2025-11-29 11:48:35',24),(40,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-24 near Angeles. Wind speed: 16.1 km/h, gusts up to 52.2 km/h.','resolved','2025-11-22 07:43:22','2025-11-29 11:48:35',25),(41,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-25 near Angeles. Wind speed: 15.9 km/h, gusts up to 54 km/h.','resolved','2025-11-22 07:43:22','2025-11-29 11:48:35',21),(42,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-26 near Baguio. Wind speed: 16.2 km/h, gusts up to 55.4 km/h.','resolved','2025-11-22 07:43:22','2025-11-29 11:48:35',26),(43,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-26 near Angeles. Wind speed: 15.6 km/h, gusts up to 70.9 km/h.','resolved','2025-11-22 07:43:22','2025-11-29 11:48:35',22),(44,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-25 near Angeles. Wind speed: 11.1 km/h, gusts up to 54.7 km/h.','resolved','2025-11-24 10:48:06','2025-12-01 13:36:59',21),(45,'typhoon','medium','Strong tropical storm conditions expected on 2025-11-26 near Angeles. Wind speed: 10.7 km/h, gusts up to 62.6 km/h.','resolved','2025-11-24 10:48:06','2025-12-01 13:36:59',22),(46,'forecast','low','Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.','resolved','2025-11-29 13:48:42','2025-12-07 07:30:13',NULL),(47,'forecast','low','Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.','resolved','2025-11-29 13:49:08','2025-12-07 07:30:13',NULL),(48,'forecast','low','Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.','resolved','2025-11-29 13:49:12','2025-12-07 07:30:13',NULL),(49,'forecast','low','Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.','resolved','2025-11-29 14:04:07','2025-12-07 07:30:13',NULL),(50,'forecast','low','Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.','resolved','2025-11-29 14:06:56','2025-12-07 07:30:13',NULL),(51,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-02). Expected precipitation: 2.6mm. Light showers may occur throughout the day.','resolved','2025-12-01 13:37:06','2025-12-08 23:19:20',NULL),(52,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.','resolved','2025-12-01 16:21:00','2025-12-08 23:19:20',NULL),(53,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.','resolved','2025-12-01 16:25:08','2025-12-08 23:19:20',NULL),(54,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.','resolved','2025-12-01 16:27:45','2025-12-08 23:19:20',NULL),(55,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.','resolved','2025-12-01 16:30:21','2025-12-08 23:19:20',NULL),(56,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.','resolved','2025-12-01 16:31:38','2025-12-08 23:19:20',NULL),(57,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.','resolved','2025-12-01 16:33:43','2025-12-08 23:19:20',NULL),(58,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 07:16:22','2025-12-03 07:16:22',NULL),(59,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 07:22:48','2025-12-03 07:22:48',NULL),(60,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 07:23:30','2025-12-03 07:23:30',NULL),(61,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 07:25:18','2025-12-03 07:25:18',NULL),(62,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 07:27:07','2025-12-03 07:27:07',NULL),(63,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 07:27:18','2025-12-03 07:27:18',NULL),(64,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 07:28:24','2025-12-03 07:28:24',NULL),(65,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.','active','2025-12-03 09:06:38','2025-12-03 09:06:38',NULL),(66,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 04:32:34','2025-12-04 04:32:34',NULL),(67,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 04:48:19','2025-12-04 04:48:19',NULL),(68,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 04:55:53','2025-12-04 04:55:53',NULL),(69,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 05:01:02','2025-12-04 05:01:02',NULL),(70,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 05:02:20','2025-12-04 05:02:20',NULL),(71,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 05:03:27','2025-12-04 05:03:27',NULL),(72,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 05:04:50','2025-12-04 05:04:50',NULL),(73,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 05:06:12','2025-12-04 05:06:12',NULL),(74,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 05:07:23','2025-12-04 05:07:23',NULL),(75,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-04 05:14:05','2025-12-04 05:14:05',NULL),(76,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.7°C. Perfect weather for outdoor farming activities.','active','2025-12-04 10:23:51','2025-12-04 10:23:51',NULL),(77,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.7°C. Perfect weather for outdoor farming activities.','active','2025-12-04 10:25:02','2025-12-04 10:25:02',NULL),(78,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-07 07:30:18','2025-12-07 07:30:18',NULL),(79,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-07 07:30:27','2025-12-07 07:30:27',NULL),(80,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-07 07:30:33','2025-12-07 07:30:33',NULL),(81,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-07 07:31:09','2025-12-07 07:31:09',NULL),(82,'forecast','low','Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.','active','2025-12-07 07:48:51','2025-12-07 07:48:51',NULL),(83,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.','active','2025-12-08 02:35:08','2025-12-08 02:35:08',NULL),(84,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.','active','2025-12-08 02:48:40','2025-12-08 02:48:40',NULL),(85,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.','active','2025-12-08 03:20:14','2025-12-08 03:20:14',NULL),(86,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.','active','2025-12-08 03:27:53','2025-12-08 03:27:53',NULL),(87,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.','active','2025-12-08 03:41:13','2025-12-08 03:41:13',NULL),(88,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.','active','2025-12-08 03:41:24','2025-12-08 03:41:24',NULL),(89,'forecast','low','Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.','active','2025-12-08 03:41:26','2025-12-08 03:41:26',NULL);
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_alerts_after_insert
AFTER INSERT ON alerts
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, new_values, created_at)
    VALUES (
        'alerts',
        NEW.id,
        'INSERT',
        JSON_OBJECT(
            'type', NEW.type,
            'severity', NEW.severity,
            'description', NEW.description,
            'status', NEW.status,
            'disaster_id', NEW.disaster_id
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_alerts_after_update
AFTER UPDATE ON alerts
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, old_values, new_values, created_at)
    VALUES (
        'alerts',
        NEW.id,
        'UPDATE',
        JSON_OBJECT(
            'type', OLD.type,
            'severity', OLD.severity,
            'status', OLD.status,
            'disaster_id', OLD.disaster_id
        ),
        JSON_OBJECT(
            'type', NEW.type,
            'severity', NEW.severity,
            'status', NEW.status,
            'disaster_id', NEW.disaster_id
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(100) NOT NULL,
  `record_id` int(11) NOT NULL,
  `action` enum('INSERT','UPDATE','DELETE') NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_audit_logs_table` (`table_name`),
  KEY `idx_audit_logs_record` (`table_name`,`record_id`),
  KEY `idx_audit_logs_user` (`user_id`),
  KEY `idx_audit_logs_action` (`action`),
  KEY `idx_audit_logs_created_at` (`created_at`),
  KEY `idx_audit_logs_table_action` (`table_name`,`action`,`created_at`),
  KEY `idx_audit_logs_user_action` (`user_id`,`action`,`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2432 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,'alerts',46,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-11-29 13:48:42'),(2,'alerts',47,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-11-29 13:49:08'),(3,'alerts',48,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-11-29 13:49:12'),(4,'alerts',49,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-11-29 14:04:07'),(5,'alerts',50,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-11-30). Expected precipitation: 1.8mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-11-29 14:06:56'),(6,'market_prices',86,'INSERT',NULL,NULL,NULL,'{\"crop_name\": \"Rice\", \"price_per_kg\": 28.41, \"location\": \"Manila\", \"date\": \"2025-12-01\"}',NULL,NULL,'2025-12-01 02:32:35'),(7,'market_prices',87,'INSERT',NULL,NULL,NULL,'{\"crop_name\": \"Corn\", \"price_per_kg\": 20.01, \"location\": \"Manila\", \"date\": \"2025-12-01\"}',NULL,NULL,'2025-12-01 02:32:37'),(8,'market_prices',88,'INSERT',NULL,NULL,NULL,'{\"crop_name\": \"Okra\", \"price_per_kg\": 35.64, \"location\": \"Manila\", \"date\": \"2025-12-01\"}',NULL,NULL,'2025-12-01 02:32:37'),(9,'market_prices',89,'INSERT',NULL,NULL,NULL,'{\"crop_name\": \"Banana\", \"price_per_kg\": 30.00, \"location\": \"Manila\", \"date\": \"2025-12-01\"}',NULL,NULL,'2025-12-01 02:32:37'),(10,'market_prices',90,'INSERT',NULL,NULL,NULL,'{\"crop_name\": \"Banana\", \"price_per_kg\": 30.00, \"location\": \"Isabela\", \"date\": \"2025-12-01\"}',NULL,NULL,'2025-12-01 02:33:59'),(11,'market_prices',91,'INSERT',NULL,NULL,NULL,'{\"crop_name\": \"Corn\", \"price_per_kg\": 21.01, \"location\": \"Isabela\", \"date\": \"2025-12-01\"}',NULL,NULL,'2025-12-01 02:34:02'),(12,'user_crops',6,'UPDATE',7,NULL,'{\"status\": \"planted\", \"health_status\": \"good\", \"expected_harvest_date\": \"2025-12-10\"}','{\"status\": \"planted\", \"health_status\": \"good\", \"expected_harvest_date\": \"2025-12-30\"}',NULL,NULL,'2025-12-01 02:35:28'),(13,'users',18,'INSERT',18,'leon',NULL,'{\"username\": \"leon\", \"role\": \"farmer\", \"full_name\": \"leonard\", \"email\": \"mark@gmail.com\", \"phone\": \"\", \"location\": \"pangasinan\", \"is_active\": 1}',NULL,NULL,'2025-12-01 02:59:04'),(14,'users',19,'INSERT',19,'arki',NULL,'{\"username\": \"arki\", \"role\": \"farmer\", \"full_name\": \"mark\", \"email\": \"mark46757@gmail.com\", \"phone\": \"\", \"location\": \"isabela\", \"is_active\": 1}',NULL,NULL,'2025-12-01 03:36:20'),(15,'users',20,'INSERT',20,'markk',NULL,'{\"username\": \"markk\", \"role\": \"farmer\", \"full_name\": \"mark\", \"email\": \"markleonard.d.delrosario@isu.edu.ph\", \"phone\": \"\", \"location\": \"isabela\", \"is_active\": 1}',NULL,NULL,'2025-12-01 04:04:24'),(16,'users',21,'INSERT',21,'markiiee',NULL,'{\"username\": \"markiiee\", \"role\": \"farmer\", \"full_name\": \"mark\", \"email\": \"markk@gmail.com\", \"phone\": \"\", \"location\": \"isabela\", \"is_active\": 1}',NULL,NULL,'2025-12-01 04:09:42'),(17,'alerts',44,'UPDATE',NULL,NULL,'{\"type\": \"typhoon\", \"severity\": \"medium\", \"status\": \"active\", \"disaster_id\": 21}','{\"type\": \"typhoon\", \"severity\": \"medium\", \"status\": \"resolved\", \"disaster_id\": 21}',NULL,NULL,'2025-12-01 13:36:59'),(18,'alerts',45,'UPDATE',NULL,NULL,'{\"type\": \"typhoon\", \"severity\": \"medium\", \"status\": \"active\", \"disaster_id\": 22}','{\"type\": \"typhoon\", \"severity\": \"medium\", \"status\": \"resolved\", \"disaster_id\": 22}',NULL,NULL,'2025-12-01 13:36:59'),(19,'alerts',51,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-02). Expected precipitation: 2.6mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-01 13:37:06'),(20,'user_crops',3,'UPDATE',7,NULL,'{\"status\": \"planted\", \"health_status\": \"good\", \"expected_harvest_date\": \"2026-07-08\"}','{\"status\": \"planted\", \"health_status\": \"good\", \"expected_harvest_date\": \"2026-01-08\"}',NULL,NULL,'2025-12-01 13:40:46'),(230,'alerts',52,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-01 16:21:00'),(253,'alerts',53,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-01 16:25:08'),(256,'alerts',54,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-01 16:27:45'),(258,'alerts',55,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-01 16:30:21'),(259,'alerts',56,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-01 16:31:38'),(261,'user_crops',7,'UPDATE',15,NULL,'{\"status\": \"planted\", \"health_status\": \"good\", \"expected_harvest_date\": \"2026-02-12\"}','{\"status\": \"planted\", \"health_status\": \"good\", \"expected_harvest_date\": \"2026-01-01\"}',NULL,NULL,'2025-12-01 16:33:06'),(390,'alerts',57,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-03). High temperature: 31.4°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-01 16:33:43'),(499,'alerts',58,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 07:16:22'),(500,'alerts',59,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 07:22:48'),(501,'alerts',60,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 07:23:30'),(502,'alerts',61,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 07:25:18'),(503,'alerts',62,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 07:27:07'),(504,'alerts',63,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 07:27:18'),(505,'alerts',64,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 07:28:24'),(506,'users',15,'UPDATE',15,'alia','{\"username\": \"bisaya\", \"role\": \"farmer\", \"full_name\": \"bisaya\", \"email\": \"bisaya@gmail.com\", \"phone\": \"\", \"location\": \"cebu\", \"is_active\": 1}','{\"username\": \"alia\", \"role\": \"farmer\", \"full_name\": \"alia\", \"email\": \"alia@gmail.com\", \"phone\": \"\", \"location\": \"cebu\", \"is_active\": 1}',NULL,NULL,'2025-12-03 07:29:07'),(861,'alerts',65,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-04). High temperature: 29.9°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-03 09:06:38'),(862,'user_crops',8,'INSERT',15,NULL,NULL,'{\"crop_name\": \"rice\", \"planting_date\": \"2025-12-03\", \"expected_harvest_date\": \"2026-09-30\", \"area_hectares\": 15.00, \"status\": \"planted\"}',NULL,NULL,'2025-12-03 09:08:22'),(990,'alerts',66,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 04:32:34'),(991,'alerts',67,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 04:48:19'),(992,'alerts',68,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 04:55:53'),(993,'alerts',69,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 05:01:02'),(994,'alerts',70,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 05:02:20'),(995,'alerts',71,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 05:03:27'),(996,'alerts',72,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 05:04:50'),(997,'alerts',73,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 05:06:12'),(998,'alerts',74,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 05:07:23'),(999,'alerts',75,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 05:14:05'),(1000,'alerts',76,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.7°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 10:23:51'),(1001,'alerts',77,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-05). High temperature: 29.7°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-04 10:25:02'),(1002,'alerts',46,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:13'),(1003,'alerts',47,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:13'),(1004,'alerts',48,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:13'),(1005,'alerts',49,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:13'),(1006,'alerts',50,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:13'),(1007,'alerts',78,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:18'),(1008,'alerts',79,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:27'),(1009,'alerts',80,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:30:33'),(1010,'alerts',81,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:31:09'),(1015,'users',22,'INSERT',22,'lee',NULL,'{\"username\": \"lee\", \"role\": \"farmer\", \"full_name\": \"leenard\", \"email\": \"lenard@gmail.com\", \"phone\": \"\", \"location\": \"echague\", \"is_active\": 1}',NULL,NULL,'2025-12-07 07:34:34'),(1016,'alerts',82,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Clear and sunny weather expected tomorrow (2025-12-08). High temperature: 29.8°C. Perfect weather for outdoor farming activities.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-07 07:48:51'),(1017,'users',23,'INSERT',23,'amy',NULL,'{\"username\": \"amy\", \"role\": \"farmer\", \"full_name\": \"amy\", \"email\": \"amy@gmail.com\", \"phone\": \"\", \"location\": \"echague\", \"is_active\": 1}',NULL,NULL,'2025-12-08 02:29:24'),(1018,'alerts',83,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 02:35:08'),(1019,'alerts',84,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 02:48:40'),(1020,'users',8,'UPDATE',8,'leonard','{\"username\": \"leonard\", \"role\": \"admin\", \"full_name\": \"Leonard Admin\", \"email\": \"admin@cropalert.com\", \"phone\": null, \"location\": \"Manila, Philippines\", \"is_active\": 1}','{\"username\": \"leonard\", \"role\": \"admin\", \"full_name\": \"Leonard Admin\", \"email\": \"admin@cropalert.com\", \"phone\": null, \"location\": \"Manila, Philippines\", \"is_active\": 1}',NULL,NULL,'2025-12-08 02:59:43'),(1089,'alerts',85,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 03:20:14'),(1124,'alerts',86,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 03:27:53'),(1193,'alerts',87,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 03:41:13'),(1194,'alerts',88,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 03:41:24'),(1195,'alerts',89,'INSERT',NULL,NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"description\": \"Slight rain or drizzle expected tomorrow (2025-12-09). Expected precipitation: 1.7mm. Light showers may occur throughout the day.\", \"status\": \"active\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 03:41:26'),(2425,'alerts',51,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 23:19:20'),(2426,'alerts',52,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 23:19:20'),(2427,'alerts',53,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 23:19:20'),(2428,'alerts',54,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 23:19:20'),(2429,'alerts',55,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 23:19:20'),(2430,'alerts',56,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 23:19:20'),(2431,'alerts',57,'UPDATE',NULL,NULL,'{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"active\", \"disaster_id\": null}','{\"type\": \"forecast\", \"severity\": \"low\", \"status\": \"resolved\", \"disaster_id\": null}',NULL,NULL,'2025-12-08 23:19:20');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bantay_presyo_commodities`
--

DROP TABLE IF EXISTS `bantay_presyo_commodities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bantay_presyo_commodities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commodity_name` varchar(255) NOT NULL,
  `commodity_code` varchar(50) NOT NULL,
  `bantay_presyo_id` varchar(50) NOT NULL COMMENT 'ID used in Bantay Presyo API',
  `category` enum('Rice','Corn','Fish','Fruits','Highland Vegetables','Lowland Vegetables','Meat and Poultry','Spices','Other Commodities') NOT NULL,
  `crop_name_mapping` varchar(255) DEFAULT NULL COMMENT 'Maps to crop_name in market_prices',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `commodity_code` (`commodity_code`),
  UNIQUE KEY `bantay_presyo_id` (`bantay_presyo_id`),
  KEY `idx_commodities_code` (`commodity_code`),
  KEY `idx_commodities_bp_id` (`bantay_presyo_id`),
  KEY `idx_commodities_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bantay_presyo_commodities`
--

LOCK TABLES `bantay_presyo_commodities` WRITE;
/*!40000 ALTER TABLE `bantay_presyo_commodities` DISABLE KEYS */;
INSERT INTO `bantay_presyo_commodities` VALUES (1,'Rice','RICE','1','Rice','Rice',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(2,'Corn','CORN','2','Corn','Corn',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(3,'Fish','FISH','3','Fish','Fish',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(4,'Fruits','FRUITS','4','Fruits',NULL,1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(5,'Highland Vegetables','HIGHLAND_VEG','5','Highland Vegetables',NULL,1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(6,'Lowland Vegetables','LOWLAND_VEG','6','Lowland Vegetables',NULL,1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(7,'Meat and Poultry','MEAT_POULTRY','7','Meat and Poultry',NULL,1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(8,'Spices','SPICES','8','Spices',NULL,1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(9,'Other Commodities','OTHER','9','Other Commodities',NULL,1,'2025-12-01 02:51:20','2025-12-01 02:51:20');
/*!40000 ALTER TABLE `bantay_presyo_commodities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bantay_presyo_markets`
--

DROP TABLE IF EXISTS `bantay_presyo_markets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bantay_presyo_markets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `market_name` varchar(255) NOT NULL,
  `region_code` varchar(50) NOT NULL,
  `location` varchar(255) NOT NULL,
  `address` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_market_region` (`market_name`,`region_code`),
  KEY `idx_markets_region` (`region_code`),
  KEY `idx_markets_location` (`location`),
  KEY `idx_markets_name` (`market_name`),
  CONSTRAINT `bantay_presyo_markets_ibfk_1` FOREIGN KEY (`region_code`) REFERENCES `bantay_presyo_regions` (`region_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bantay_presyo_markets`
--

LOCK TABLES `bantay_presyo_markets` WRITE;
/*!40000 ALTER TABLE `bantay_presyo_markets` DISABLE KEYS */;
/*!40000 ALTER TABLE `bantay_presyo_markets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bantay_presyo_regions`
--

DROP TABLE IF EXISTS `bantay_presyo_regions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bantay_presyo_regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(255) NOT NULL,
  `region_code` varchar(50) NOT NULL,
  `bantay_presyo_id` varchar(50) NOT NULL COMMENT 'ID used in Bantay Presyo API',
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `region_code` (`region_code`),
  UNIQUE KEY `bantay_presyo_id` (`bantay_presyo_id`),
  KEY `idx_regions_code` (`region_code`),
  KEY `idx_regions_bp_id` (`bantay_presyo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bantay_presyo_regions`
--

LOCK TABLES `bantay_presyo_regions` WRITE;
/*!40000 ALTER TABLE `bantay_presyo_regions` DISABLE KEYS */;
INSERT INTO `bantay_presyo_regions` VALUES (1,'National Capital Region','NCR','130000000','Metro Manila',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(2,'Cordillera Administrative Region','CAR','140000000','CAR',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(3,'Region I - Ilocos Region','REGION_I','100000000','Ilocos Region',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(4,'Region II - Cagayan Valley','REGION_II','200000000','Cagayan Valley',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(5,'Region III - Central Luzon','REGION_III','300000000','Central Luzon',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(6,'Region IV-B - MIMAROPA','REGION_IV_A','400000000','MIMAROPA',1,'2025-12-01 02:51:20','2025-12-01 02:52:44'),(7,'Region V - Bicol Region','REGION_V','500000000','Bicol Region',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(8,'Region VI - Western Visayas','REGION_VI','600000000','Western Visayas',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(9,'Region VII - Central Visayas','REGION_VII','700000000','Central Visayas (Cebu)',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(10,'Region VIII - Eastern Visayas','REGION_VIII','800000000','Eastern Visayas',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(11,'Region IX - Zamboanga Peninsula','REGION_IX','900000000','Zamboanga Peninsula',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(12,'Region X - Northern Mindanao','REGION_X','1000000000','Northern Mindanao',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(13,'Region XI - Davao Region','REGION_XI','1100000000','Davao Region',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(14,'Region XII - SOCCSKSARGEN','REGION_XII','1200000000','SOCCSKSARGEN',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(15,'BARMM','BARMM','1500000000','Bangsamoro Autonomous Region',1,'2025-12-01 02:51:20','2025-12-01 02:51:20'),(16,'Region XIII - Caraga','REGION_XIII','1600000000','Caraga',1,'2025-12-01 02:51:20','2025-12-01 02:51:20');
/*!40000 ALTER TABLE `bantay_presyo_regions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bantay_presyo_scraping_log`
--

DROP TABLE IF EXISTS `bantay_presyo_scraping_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bantay_presyo_scraping_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_code` varchar(50) NOT NULL,
  `commodity_code` varchar(50) NOT NULL,
  `scraping_date` date NOT NULL,
  `status` enum('success','failed','partial') NOT NULL,
  `records_scraped` int(11) DEFAULT 0,
  `records_stored` int(11) DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `execution_time_seconds` decimal(10,2) DEFAULT NULL,
  `started_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `commodity_code` (`commodity_code`),
  KEY `idx_scraping_log_date` (`scraping_date`),
  KEY `idx_scraping_log_region_commodity` (`region_code`,`commodity_code`),
  KEY `idx_scraping_log_status` (`status`),
  CONSTRAINT `bantay_presyo_scraping_log_ibfk_1` FOREIGN KEY (`region_code`) REFERENCES `bantay_presyo_regions` (`region_code`),
  CONSTRAINT `bantay_presyo_scraping_log_ibfk_2` FOREIGN KEY (`commodity_code`) REFERENCES `bantay_presyo_commodities` (`commodity_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bantay_presyo_scraping_log`
--

LOCK TABLES `bantay_presyo_scraping_log` WRITE;
/*!40000 ALTER TABLE `bantay_presyo_scraping_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `bantay_presyo_scraping_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crop_recommendations`
--

DROP TABLE IF EXISTS `crop_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crop_recommendations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crop_name` varchar(100) NOT NULL,
  `crop_type_id` int(11) DEFAULT NULL,
  `season` enum('spring','summer','autumn','winter') NOT NULL,
  `suitability` enum('low','medium','high') NOT NULL,
  `description` text DEFAULT NULL,
  `planting_time` varchar(100) DEFAULT NULL,
  `temperature_min` decimal(5,2) DEFAULT NULL,
  `temperature_max` decimal(5,2) DEFAULT NULL,
  `rainfall_min` decimal(5,2) DEFAULT NULL,
  `rainfall_max` decimal(5,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_crop_recommendations_season` (`season`),
  KEY `idx_crop_rec_season_suitability` (`season`,`suitability`),
  KEY `idx_crop_rec_crop_name` (`crop_name`),
  KEY `idx_crop_rec_suitability` (`suitability`),
  KEY `idx_crop_rec_crop_season` (`crop_name`,`season`),
  FULLTEXT KEY `ft_idx_crop_rec_description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crop_recommendations`
--

LOCK TABLES `crop_recommendations` WRITE;
/*!40000 ALTER TABLE `crop_recommendations` DISABLE KEYS */;
INSERT INTO `crop_recommendations` VALUES (1,'Rice',NULL,'spring','high','Staple crop ideal for spring planting','March-May',20.00,35.00,100.00,300.00,'2025-11-08 07:57:29'),(2,'Corn',NULL,'spring','high','Good spring crop with high yield potential','April-June',18.00,32.00,50.00,200.00,'2025-11-08 07:57:29'),(3,'Tomatoes',NULL,'spring','medium','Warm season vegetable','March-April',15.00,30.00,30.00,150.00,'2025-11-08 07:57:29'),(4,'Okra',NULL,'summer','high','Heat-tolerant vegetable','June-August',25.00,40.00,40.00,200.00,'2025-11-08 07:57:29'),(5,'Eggplant',NULL,'summer','high','Summer vegetable with good heat tolerance','May-July',20.00,35.00,50.00,250.00,'2025-11-08 07:57:29'),(6,'Pepper',NULL,'summer','medium','Hot weather crop','June-July',22.00,35.00,30.00,200.00,'2025-11-08 07:57:29'),(7,'Cabbage',NULL,'autumn','high','Cool season crop','September-November',10.00,25.00,40.00,200.00,'2025-11-08 07:57:29'),(8,'Carrots',NULL,'autumn','high','Root vegetable for fall','August-October',8.00,25.00,30.00,150.00,'2025-11-08 07:57:29'),(9,'Lettuce',NULL,'autumn','medium','Cool weather green','September-October',5.00,20.00,20.00,100.00,'2025-11-08 07:57:29'),(10,'Wheat',NULL,'winter','high','Winter grain crop','November-January',5.00,20.00,30.00,150.00,'2025-11-08 07:57:29'),(11,'Onions',NULL,'winter','high','Winter vegetable','December-February',8.00,25.00,20.00,120.00,'2025-11-08 07:57:29'),(12,'Garlic',NULL,'winter','medium','Winter bulb crop','November-December',5.00,25.00,15.00,100.00,'2025-11-08 07:57:29');
/*!40000 ALTER TABLE `crop_recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crop_statistics_aggregates`
--

DROP TABLE IF EXISTS `crop_statistics_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crop_statistics_aggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_date` date NOT NULL,
  `total_crops` int(11) NOT NULL DEFAULT 0,
  `total_farmers_with_crops` int(11) NOT NULL DEFAULT 0,
  `crop_distribution` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`crop_distribution`)),
  `crop_by_status` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`crop_by_status`)),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_date` (`aggregate_date`),
  KEY `idx_aggregate_date` (`aggregate_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crop_statistics_aggregates`
--

LOCK TABLES `crop_statistics_aggregates` WRITE;
/*!40000 ALTER TABLE `crop_statistics_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `crop_statistics_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crop_types`
--

DROP TABLE IF EXISTS `crop_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crop_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crop_name` varchar(100) NOT NULL,
  `scientific_name` varchar(255) DEFAULT NULL,
  `category` enum('grain','vegetable','fruit','legume','root_crop','other') DEFAULT 'other',
  `growing_season` enum('dry','wet','both') DEFAULT 'both',
  `average_growth_days` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `crop_name` (`crop_name`),
  KEY `idx_crop_types_name` (`crop_name`),
  KEY `idx_crop_types_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crop_types`
--

LOCK TABLES `crop_types` WRITE;
/*!40000 ALTER TABLE `crop_types` DISABLE KEYS */;
INSERT INTO `crop_types` VALUES (1,'banana',NULL,'fruit','both',NULL,'2025-12-02 12:42:28'),(2,'corn',NULL,'grain','both',NULL,'2025-12-02 12:42:28'),(3,'okra',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(4,'potato',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(5,'rice',NULL,'grain','both',NULL,'2025-12-02 12:42:28'),(8,'Eggplant',NULL,'vegetable','both',NULL,'2025-12-02 12:42:28'),(9,'mark',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(10,'Tomato',NULL,'vegetable','both',NULL,'2025-12-02 12:42:28'),(11,'Cabbage',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(12,'Carrots',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(13,'Garlic',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(14,'Lettuce',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(15,'Onions',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(16,'Pepper',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(17,'Tomatoes',NULL,'other','both',NULL,'2025-12-02 12:42:28'),(18,'Wheat',NULL,'other','both',NULL,'2025-12-02 12:42:28');
/*!40000 ALTER TABLE `crop_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_user_statistics`
--

DROP TABLE IF EXISTS `daily_user_statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_user_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_date` date NOT NULL,
  `total_users` int(11) NOT NULL DEFAULT 0,
  `total_farmers` int(11) NOT NULL DEFAULT 0,
  `total_admins` int(11) NOT NULL DEFAULT 0,
  `new_users_today` int(11) NOT NULL DEFAULT 0,
  `new_farmers_today` int(11) NOT NULL DEFAULT 0,
  `active_users_count` int(11) DEFAULT 0,
  `active_farmers_count` int(11) DEFAULT 0,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_date` (`aggregate_date`),
  KEY `idx_aggregate_date` (`aggregate_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_user_statistics`
--

LOCK TABLES `daily_user_statistics` WRITE;
/*!40000 ALTER TABLE `daily_user_statistics` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_user_statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_weather_aggregates`
--

DROP TABLE IF EXISTS `daily_weather_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `daily_weather_aggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_date` date NOT NULL,
  `record_count` int(11) NOT NULL DEFAULT 0,
  `avg_temperature` decimal(5,2) DEFAULT NULL,
  `avg_humidity` decimal(5,2) DEFAULT NULL,
  `total_rainfall` decimal(8,2) DEFAULT 0.00,
  `avg_wind_speed` decimal(5,2) DEFAULT NULL,
  `condition_distribution` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`condition_distribution`)),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_date` (`aggregate_date`),
  KEY `idx_aggregate_date` (`aggregate_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_weather_aggregates`
--

LOCK TABLES `daily_weather_aggregates` WRITE;
/*!40000 ALTER TABLE `daily_weather_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `daily_weather_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disaster_affected_areas`
--

DROP TABLE IF EXISTS `disaster_affected_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disaster_affected_areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `disaster_id` int(11) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `sequence_order` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_disaster_id` (`disaster_id`),
  KEY `idx_coordinates` (`latitude`,`longitude`),
  KEY `idx_disaster_areas_disaster_sequence` (`disaster_id`,`sequence_order`),
  CONSTRAINT `disaster_affected_areas_ibfk_1` FOREIGN KEY (`disaster_id`) REFERENCES `disasters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disaster_affected_areas`
--

LOCK TABLES `disaster_affected_areas` WRITE;
/*!40000 ALTER TABLE `disaster_affected_areas` DISABLE KEYS */;
/*!40000 ALTER TABLE `disaster_affected_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `disasters`
--

DROP TABLE IF EXISTS `disasters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `disasters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `type` enum('typhoon','flood','drought','earthquake','pest_outbreak','disease_outbreak','other') NOT NULL,
  `severity` enum('low','medium','high','critical') NOT NULL DEFAULT 'medium',
  `status` enum('active','warning','resolved','cancelled') NOT NULL DEFAULT 'active',
  `description` text DEFAULT NULL,
  `center_latitude` decimal(10,8) DEFAULT NULL,
  `center_longitude` decimal(11,8) DEFAULT NULL,
  `affected_radius_km` decimal(8,2) DEFAULT NULL,
  `affected_areas` text DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_disasters_status` (`status`),
  KEY `idx_disasters_type` (`type`),
  KEY `idx_disasters_created_at` (`created_at`),
  KEY `idx_disasters_dates` (`start_date`,`end_date`),
  KEY `idx_disasters_status_dates` (`status`,`start_date`,`end_date`),
  KEY `idx_disasters_type_severity` (`type`,`severity`),
  KEY `idx_disasters_status_type_severity` (`status`,`type`,`severity`),
  KEY `idx_disasters_coordinates` (`center_latitude`,`center_longitude`),
  FULLTEXT KEY `ft_idx_disasters_description` (`description`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `disasters`
--

LOCK TABLES `disasters` WRITE;
/*!40000 ALTER TABLE `disasters` DISABLE KEYS */;
INSERT INTO `disasters` VALUES (1,'Typhoon Sample','typhoon','high','active','Sample typhoon affecting multiple regions',14.59950000,120.98420000,50.00,NULL,'2025-11-08 16:08:35',NULL,'2025-11-08 08:08:35','2025-11-08 08:08:35'),(2,'Category 1-2 Typhoon - Manila (2025-11-09)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-09 near Manila. Wind speed: 70.7 km/h, gusts up to 116.6 km/h. Precipitation: 28.4mm.',14.59950000,120.98420000,100.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(3,'Tropical Storm - Cebu (2025-11-09)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-09 near Cebu. Wind speed: 50.3 km/h, gusts up to 71.3 km/h.',10.31570000,123.88540000,50.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(4,'Tropical Storm - Baguio (2025-11-09)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-09 near Baguio. Wind speed: 49.5 km/h, gusts up to 142.2 km/h. Precipitation: 45.7mm.',16.40230000,120.59600000,50.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(5,'Tropical Storm - Naga (2025-11-09)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-09 near Naga. Wind speed: 69.8 km/h, gusts up to 155.9 km/h. Precipitation: 172.3mm.',13.41250000,123.41330000,100.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(6,'Tropical Storm - Tacloban (2025-11-09)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-09 near Tacloban. Wind speed: 27 km/h, gusts up to 65.9 km/h.',11.24340000,125.00490000,25.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(7,'Tropical Storm - Cagayan de Oro (2025-11-09)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-09 near Cagayan de Oro. Wind speed: 33.3 km/h, gusts up to 55.4 km/h.',8.48440000,124.64720000,25.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(8,'Tropical Storm - Angeles (2025-11-09)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-09 near Angeles. Wind speed: 29 km/h, gusts up to 94 km/h. Precipitation: 28.6mm.',15.14480000,120.58470000,25.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(9,'Category 1-2 Typhoon - Quezon City (2025-11-09)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-09 near Quezon City. Wind speed: 70.7 km/h, gusts up to 116.6 km/h. Precipitation: 28.4mm.',14.67600000,121.04370000,100.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(10,'Tropical Storm - Zamboanga (2025-11-09)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-09 near Zamboanga. Wind speed: 37.1 km/h, gusts up to 54.4 km/h.',6.92140000,122.07900000,25.00,NULL,'2025-11-09 00:00:00','2025-11-09 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(11,'Tropical Storm - Manila (2025-11-10)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-10 near Manila. Wind speed: 54.9 km/h, gusts up to 86.4 km/h. Precipitation: 55.3mm.',14.59950000,120.98420000,50.00,NULL,'2025-11-10 00:00:00','2025-11-10 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(12,'Tropical Storm - Cebu (2025-11-10)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-10 near Cebu. Wind speed: 42.3 km/h, gusts up to 57.6 km/h.',10.31570000,123.88540000,50.00,NULL,'2025-11-10 00:00:00','2025-11-10 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(13,'Tropical Storm - Baguio (2025-11-10)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-10 near Baguio. Wind speed: 54 km/h, gusts up to 130.3 km/h. Precipitation: 64.4mm.',16.40230000,120.59600000,50.00,NULL,'2025-11-10 00:00:00','2025-11-10 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(14,'Tropical Storm - Naga (2025-11-10)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-10 near Naga. Wind speed: 26.6 km/h, gusts up to 67.3 km/h.',13.41250000,123.41330000,25.00,NULL,'2025-11-10 00:00:00','2025-11-10 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(15,'Tropical Storm - Angeles (2025-11-10)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-10 near Angeles. Wind speed: 25.6 km/h, gusts up to 86.4 km/h. Precipitation: 24.7mm.',15.14480000,120.58470000,25.00,NULL,'2025-11-10 00:00:00','2025-11-10 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(16,'Tropical Storm - Quezon City (2025-11-10)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-10 near Quezon City. Wind speed: 54.9 km/h, gusts up to 86.4 km/h. Precipitation: 55.3mm.',14.67600000,121.04370000,50.00,NULL,'2025-11-10 00:00:00','2025-11-10 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(17,'Tropical Storm - Manila (2025-11-11)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-11 near Manila. Wind speed: 40.4 km/h, gusts up to 60.8 km/h.',14.59950000,120.98420000,50.00,NULL,'2025-11-11 00:00:00','2025-11-11 23:59:59','2025-11-08 09:23:22','2025-11-09 03:22:58'),(18,'Tropical Storm - Baguio (2025-11-11)','typhoon','high','warning','Typhoon-level winds expected on 2025-11-11 near Baguio. Wind speed: 19.1 km/h, gusts up to 80.3 km/h. Precipitation: 5.5mm.',16.40230000,120.59600000,25.00,NULL,'2025-11-11 00:00:00','2025-11-11 23:59:59','2025-11-08 09:23:23','2025-11-09 03:22:58'),(19,'Tropical Storm - Angeles (2025-11-11)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-11 near Angeles. Wind speed: 19 km/h, gusts up to 63 km/h.',15.14480000,120.58470000,25.00,NULL,'2025-11-11 00:00:00','2025-11-11 23:59:59','2025-11-08 09:23:23','2025-11-09 03:22:58'),(20,'Tropical Storm - Quezon City (2025-11-11)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-11 near Quezon City. Wind speed: 40.4 km/h, gusts up to 60.8 km/h.',14.67600000,121.04370000,50.00,NULL,'2025-11-11 00:00:00','2025-11-11 23:59:59','2025-11-08 09:23:23','2025-11-09 03:22:58'),(21,'Tropical Storm - Angeles (2025-11-25)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-25 near Angeles. Wind speed: 10.5 km/h, gusts up to 56.9 km/h.',15.14480000,120.58470000,25.00,NULL,'2025-11-25 00:00:00','2025-11-25 23:59:59','2025-11-20 02:33:40','2025-11-24 23:45:01'),(22,'Tropical Storm - Angeles (2025-11-26)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-26 near Angeles. Wind speed: 11.2 km/h, gusts up to 58.3 km/h.',15.14480000,120.58470000,25.00,NULL,'2025-11-26 00:00:00','2025-11-26 23:59:59','2025-11-20 02:33:40','2025-11-24 23:45:01'),(23,'Tropical Storm - Angeles (2025-11-22)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-22 near Angeles. Wind speed: 15.7 km/h, gusts up to 61.6 km/h.',15.14480000,120.58470000,25.00,NULL,'2025-11-22 00:00:00','2025-11-22 23:59:59','2025-11-22 07:43:22','2025-11-22 09:05:30'),(24,'Tropical Storm - Angeles (2025-11-23)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-23 near Angeles. Wind speed: 18.2 km/h, gusts up to 51.5 km/h.',15.14480000,120.58470000,25.00,NULL,'2025-11-23 00:00:00','2025-11-23 23:59:59','2025-11-22 07:43:22','2025-11-22 09:05:30'),(25,'Tropical Storm - Angeles (2025-11-24)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-24 near Angeles. Wind speed: 16.1 km/h, gusts up to 52.2 km/h.',15.14480000,120.58470000,25.00,NULL,'2025-11-24 00:00:00','2025-11-24 23:59:59','2025-11-22 07:43:22','2025-11-22 09:05:30'),(26,'Tropical Storm - Baguio (2025-11-26)','typhoon','medium','warning','Strong tropical storm conditions expected on 2025-11-26 near Baguio. Wind speed: 16.2 km/h, gusts up to 55.4 km/h.',16.40230000,120.59600000,25.00,NULL,'2025-11-26 00:00:00','2025-11-26 23:59:59','2025-11-22 07:43:22','2025-11-22 09:05:30');
/*!40000 ALTER TABLE `disasters` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_disasters_after_insert
AFTER INSERT ON disasters
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, new_values, created_at)
    VALUES (
        'disasters',
        NEW.id,
        'INSERT',
        JSON_OBJECT(
            'name', NEW.name,
            'type', NEW.type,
            'severity', NEW.severity,
            'status', NEW.status
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_disasters_after_update
AFTER UPDATE ON disasters
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, old_values, new_values, created_at)
    VALUES (
        'disasters',
        NEW.id,
        'UPDATE',
        JSON_OBJECT(
            'name', OLD.name,
            'type', OLD.type,
            'severity', OLD.severity,
            'status', OLD.status
        ),
        JSON_OBJECT(
            'name', NEW.name,
            'type', NEW.type,
            'severity', NEW.severity,
            'status', NEW.status
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `email_notifications`
--

DROP TABLE IF EXISTS `email_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `alert_id` int(11) DEFAULT NULL,
  `notification_type` enum('verification','alert','welcome','other') NOT NULL DEFAULT 'other',
  `email_address` varchar(100) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_alert` (`user_id`,`alert_id`),
  KEY `idx_email_notifications_user_id` (`user_id`),
  KEY `idx_email_notifications_alert_id` (`alert_id`),
  KEY `idx_email_notifications_status` (`status`),
  KEY `idx_email_notifications_created_at` (`created_at`),
  CONSTRAINT `email_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `email_notifications_ibfk_2` FOREIGN KEY (`alert_id`) REFERENCES `alerts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=250 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_notifications`
--

LOCK TABLES `email_notifications` WRITE;
/*!40000 ALTER TABLE `email_notifications` DISABLE KEYS */;
INSERT INTO `email_notifications` VALUES (1,8,51,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 13:37:06','2025-12-01 13:37:06'),(2,15,51,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 13:37:06','2025-12-01 13:37:06'),(3,18,51,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 13:37:06','2025-12-01 13:37:06'),(4,19,51,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 13:37:07','2025-12-01 13:37:07'),(5,20,51,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 13:37:07','2025-12-01 13:37:07'),(6,21,51,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 13:37:07','2025-12-01 13:37:07'),(7,8,52,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:21:00','2025-12-01 16:21:00'),(8,15,52,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:21:01','2025-12-01 16:21:01'),(9,18,52,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:21:01','2025-12-01 16:21:01'),(10,19,52,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:21:01','2025-12-01 16:21:01'),(11,20,52,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:21:01','2025-12-01 16:21:01'),(12,21,52,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:21:02','2025-12-01 16:21:02'),(13,8,53,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:25:08','2025-12-01 16:25:08'),(14,15,53,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:25:09','2025-12-01 16:25:09'),(15,18,53,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:25:09','2025-12-01 16:25:09'),(16,19,53,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:25:09','2025-12-01 16:25:09'),(17,20,53,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:25:09','2025-12-01 16:25:09'),(18,21,53,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:25:09','2025-12-01 16:25:09'),(19,8,54,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:27:45','2025-12-01 16:27:45'),(20,15,54,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:27:45','2025-12-01 16:27:45'),(21,18,54,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:27:45','2025-12-01 16:27:45'),(22,19,54,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:27:45','2025-12-01 16:27:45'),(23,20,54,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:27:46','2025-12-01 16:27:46'),(24,21,54,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:27:46','2025-12-01 16:27:46'),(25,8,55,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:30:21','2025-12-01 16:30:21'),(26,15,55,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:30:21','2025-12-01 16:30:21'),(27,18,55,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:30:22','2025-12-01 16:30:22'),(28,19,55,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:30:22','2025-12-01 16:30:22'),(29,20,55,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:30:22','2025-12-01 16:30:22'),(30,21,55,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:30:22','2025-12-01 16:30:22'),(31,8,56,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:31:38','2025-12-01 16:31:38'),(32,15,56,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:31:38','2025-12-01 16:31:38'),(33,18,56,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:31:39','2025-12-01 16:31:39'),(34,19,56,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:31:39','2025-12-01 16:31:39'),(35,20,56,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:31:39','2025-12-01 16:31:39'),(36,21,56,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:31:39','2025-12-01 16:31:39'),(37,8,57,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:33:43','2025-12-01 16:33:43'),(38,15,57,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:33:43','2025-12-01 16:33:43'),(39,18,57,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:33:43','2025-12-01 16:33:43'),(40,19,57,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:33:43','2025-12-01 16:33:43'),(41,20,57,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:33:44','2025-12-01 16:33:44'),(42,21,57,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-01 16:33:44','2025-12-01 16:33:44'),(43,8,58,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:16:22','2025-12-03 07:16:22'),(44,15,58,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:16:22','2025-12-03 07:16:22'),(45,18,58,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:16:22','2025-12-03 07:16:22'),(46,19,58,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:16:22','2025-12-03 07:16:22'),(47,20,58,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:16:23','2025-12-03 07:16:23'),(48,21,58,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:16:23','2025-12-03 07:16:23'),(49,8,59,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:22:48','2025-12-03 07:22:48'),(50,15,59,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:22:48','2025-12-03 07:22:48'),(51,18,59,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:22:48','2025-12-03 07:22:48'),(52,19,59,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:22:48','2025-12-03 07:22:48'),(53,20,59,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:22:49','2025-12-03 07:22:49'),(54,21,59,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:22:49','2025-12-03 07:22:49'),(55,8,60,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:23:30','2025-12-03 07:23:30'),(56,15,60,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:23:30','2025-12-03 07:23:30'),(57,18,60,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:23:31','2025-12-03 07:23:31'),(58,19,60,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:23:31','2025-12-03 07:23:31'),(59,20,60,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:23:31','2025-12-03 07:23:31'),(60,21,60,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:23:31','2025-12-03 07:23:31'),(61,8,61,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:25:18','2025-12-03 07:25:18'),(62,15,61,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:25:18','2025-12-03 07:25:18'),(63,18,61,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:25:18','2025-12-03 07:25:18'),(64,19,61,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:25:18','2025-12-03 07:25:18'),(65,20,61,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:25:19','2025-12-03 07:25:19'),(66,21,61,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:25:19','2025-12-03 07:25:19'),(67,8,62,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:07','2025-12-03 07:27:07'),(68,15,62,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:07','2025-12-03 07:27:07'),(69,18,62,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:07','2025-12-03 07:27:07'),(70,19,62,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:07','2025-12-03 07:27:07'),(71,20,62,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:07','2025-12-03 07:27:07'),(72,21,62,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:08','2025-12-03 07:27:08'),(73,8,63,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:18','2025-12-03 07:27:18'),(74,15,63,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:18','2025-12-03 07:27:18'),(75,18,63,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:18','2025-12-03 07:27:18'),(76,19,63,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:19','2025-12-03 07:27:19'),(77,20,63,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:19','2025-12-03 07:27:19'),(78,21,63,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:27:19','2025-12-03 07:27:19'),(79,8,64,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:28:24','2025-12-03 07:28:24'),(80,15,64,'alert','bisaya@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:28:24','2025-12-03 07:28:24'),(81,18,64,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:28:24','2025-12-03 07:28:24'),(82,19,64,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:28:25','2025-12-03 07:28:25'),(83,20,64,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:28:25','2025-12-03 07:28:25'),(84,21,64,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 07:28:25','2025-12-03 07:28:25'),(85,8,65,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 09:06:38','2025-12-03 09:06:38'),(86,15,65,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 09:06:39','2025-12-03 09:06:39'),(87,18,65,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 09:06:39','2025-12-03 09:06:39'),(88,19,65,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 09:06:39','2025-12-03 09:06:39'),(89,20,65,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 09:06:39','2025-12-03 09:06:39'),(90,21,65,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-03 09:06:39','2025-12-03 09:06:39'),(91,8,66,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:32:34','2025-12-04 04:32:34'),(92,15,66,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:32:34','2025-12-04 04:32:34'),(93,18,66,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:32:35','2025-12-04 04:32:35'),(94,19,66,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:32:35','2025-12-04 04:32:35'),(95,20,66,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:32:35','2025-12-04 04:32:35'),(96,21,66,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:32:35','2025-12-04 04:32:35'),(97,8,67,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:48:19','2025-12-04 04:48:19'),(98,15,67,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:48:19','2025-12-04 04:48:19'),(99,18,67,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:48:19','2025-12-04 04:48:19'),(100,19,67,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:48:19','2025-12-04 04:48:19'),(101,20,67,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:48:20','2025-12-04 04:48:20'),(102,21,67,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:48:20','2025-12-04 04:48:20'),(103,8,68,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:55:53','2025-12-04 04:55:53'),(104,15,68,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:55:53','2025-12-04 04:55:53'),(105,18,68,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:55:53','2025-12-04 04:55:53'),(106,19,68,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:55:54','2025-12-04 04:55:54'),(107,20,68,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:55:54','2025-12-04 04:55:54'),(108,21,68,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 04:55:54','2025-12-04 04:55:54'),(109,8,69,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:01:02','2025-12-04 05:01:02'),(110,15,69,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:01:02','2025-12-04 05:01:02'),(111,18,69,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:01:02','2025-12-04 05:01:02'),(112,19,69,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:01:03','2025-12-04 05:01:03'),(113,20,69,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:01:03','2025-12-04 05:01:03'),(114,21,69,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:01:03','2025-12-04 05:01:03'),(115,8,70,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:02:20','2025-12-04 05:02:20'),(116,15,70,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:02:21','2025-12-04 05:02:21'),(117,18,70,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:02:21','2025-12-04 05:02:21'),(118,19,70,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:02:21','2025-12-04 05:02:21'),(119,20,70,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:02:21','2025-12-04 05:02:21'),(120,21,70,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:02:21','2025-12-04 05:02:21'),(121,8,71,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:03:27','2025-12-04 05:03:27'),(122,15,71,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:03:27','2025-12-04 05:03:27'),(123,18,71,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:03:27','2025-12-04 05:03:27'),(124,19,71,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:03:27','2025-12-04 05:03:27'),(125,20,71,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:03:27','2025-12-04 05:03:27'),(126,21,71,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:03:28','2025-12-04 05:03:28'),(127,8,72,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:04:50','2025-12-04 05:04:50'),(128,15,72,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:04:50','2025-12-04 05:04:50'),(129,18,72,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:04:50','2025-12-04 05:04:50'),(130,19,72,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:04:50','2025-12-04 05:04:50'),(131,20,72,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:04:51','2025-12-04 05:04:51'),(132,21,72,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:04:51','2025-12-04 05:04:51'),(133,8,73,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:06:12','2025-12-04 05:06:12'),(134,15,73,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:06:13','2025-12-04 05:06:13'),(135,18,73,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:06:13','2025-12-04 05:06:13'),(136,19,73,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:06:13','2025-12-04 05:06:13'),(137,20,73,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:06:13','2025-12-04 05:06:13'),(138,21,73,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:06:13','2025-12-04 05:06:13'),(139,8,74,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:07:23','2025-12-04 05:07:23'),(140,15,74,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:07:23','2025-12-04 05:07:23'),(141,18,74,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:07:24','2025-12-04 05:07:24'),(142,19,74,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:07:24','2025-12-04 05:07:24'),(143,20,74,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:07:24','2025-12-04 05:07:24'),(144,21,74,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:07:24','2025-12-04 05:07:24'),(145,8,75,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:14:05','2025-12-04 05:14:05'),(146,15,75,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:14:06','2025-12-04 05:14:06'),(147,18,75,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:14:06','2025-12-04 05:14:06'),(148,19,75,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:14:06','2025-12-04 05:14:06'),(149,20,75,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:14:06','2025-12-04 05:14:06'),(150,21,75,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 05:14:06','2025-12-04 05:14:06'),(151,8,76,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:23:51','2025-12-04 10:23:51'),(152,15,76,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:23:51','2025-12-04 10:23:51'),(153,18,76,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:23:51','2025-12-04 10:23:51'),(154,19,76,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:23:52','2025-12-04 10:23:52'),(155,20,76,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:23:52','2025-12-04 10:23:52'),(156,21,76,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:23:52','2025-12-04 10:23:52'),(157,8,77,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:25:02','2025-12-04 10:25:02'),(158,15,77,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:25:02','2025-12-04 10:25:02'),(159,18,77,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:25:02','2025-12-04 10:25:02'),(160,19,77,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:25:02','2025-12-04 10:25:02'),(161,20,77,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:25:02','2025-12-04 10:25:02'),(162,21,77,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-04 10:25:03','2025-12-04 10:25:03'),(163,8,78,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:18','2025-12-07 07:30:18'),(164,15,78,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:18','2025-12-07 07:30:18'),(165,18,78,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:18','2025-12-07 07:30:18'),(166,19,78,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:18','2025-12-07 07:30:18'),(167,20,78,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:19','2025-12-07 07:30:19'),(168,21,78,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:19','2025-12-07 07:30:19'),(169,8,79,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:27','2025-12-07 07:30:27'),(170,15,79,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:27','2025-12-07 07:30:27'),(171,18,79,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:27','2025-12-07 07:30:27'),(172,19,79,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:27','2025-12-07 07:30:27'),(173,20,79,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:27','2025-12-07 07:30:27'),(174,21,79,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:28','2025-12-07 07:30:28'),(175,8,80,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:33','2025-12-07 07:30:33'),(176,15,80,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:33','2025-12-07 07:30:33'),(177,18,80,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:34','2025-12-07 07:30:34'),(178,19,80,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:34','2025-12-07 07:30:34'),(179,20,80,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:34','2025-12-07 07:30:34'),(180,21,80,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:30:34','2025-12-07 07:30:34'),(181,8,81,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:31:09','2025-12-07 07:31:09'),(182,15,81,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:31:09','2025-12-07 07:31:09'),(183,18,81,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:31:09','2025-12-07 07:31:09'),(184,19,81,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:31:09','2025-12-07 07:31:09'),(185,20,81,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:31:10','2025-12-07 07:31:10'),(186,21,81,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:31:10','2025-12-07 07:31:10'),(187,8,82,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:48:51','2025-12-07 07:48:51'),(188,15,82,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:48:51','2025-12-07 07:48:51'),(189,18,82,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:48:52','2025-12-07 07:48:52'),(190,19,82,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:48:52','2025-12-07 07:48:52'),(191,20,82,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:48:52','2025-12-07 07:48:52'),(192,21,82,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:48:52','2025-12-07 07:48:52'),(193,22,82,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-07 07:48:52','2025-12-07 07:48:52'),(194,8,83,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:08','2025-12-08 02:35:08'),(195,15,83,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:08','2025-12-08 02:35:08'),(196,18,83,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:08','2025-12-08 02:35:08'),(197,19,83,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:08','2025-12-08 02:35:08'),(198,20,83,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:09','2025-12-08 02:35:09'),(199,21,83,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:09','2025-12-08 02:35:09'),(200,22,83,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:09','2025-12-08 02:35:09'),(201,23,83,'alert','amy@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:35:09','2025-12-08 02:35:09'),(202,8,84,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:40','2025-12-08 02:48:40'),(203,15,84,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:41','2025-12-08 02:48:41'),(204,18,84,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:41','2025-12-08 02:48:41'),(205,19,84,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:41','2025-12-08 02:48:41'),(206,20,84,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:41','2025-12-08 02:48:41'),(207,21,84,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:41','2025-12-08 02:48:41'),(208,22,84,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:42','2025-12-08 02:48:42'),(209,23,84,'alert','amy@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 02:48:42','2025-12-08 02:48:42'),(210,8,85,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:14','2025-12-08 03:20:14'),(211,15,85,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:14','2025-12-08 03:20:14'),(212,18,85,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:14','2025-12-08 03:20:14'),(213,19,85,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:15','2025-12-08 03:20:15'),(214,20,85,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:15','2025-12-08 03:20:15'),(215,21,85,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:15','2025-12-08 03:20:15'),(216,22,85,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:15','2025-12-08 03:20:15'),(217,23,85,'alert','amy@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:20:15','2025-12-08 03:20:15'),(218,8,86,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:53','2025-12-08 03:27:53'),(219,15,86,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:54','2025-12-08 03:27:54'),(220,18,86,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:54','2025-12-08 03:27:54'),(221,19,86,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:54','2025-12-08 03:27:54'),(222,20,86,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:54','2025-12-08 03:27:54'),(223,21,86,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:54','2025-12-08 03:27:54'),(224,22,86,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:55','2025-12-08 03:27:55'),(225,23,86,'alert','amy@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:27:55','2025-12-08 03:27:55'),(226,8,87,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:13','2025-12-08 03:41:13'),(227,15,87,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:13','2025-12-08 03:41:13'),(228,18,87,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:13','2025-12-08 03:41:13'),(229,19,87,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:13','2025-12-08 03:41:13'),(230,20,87,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:13','2025-12-08 03:41:13'),(231,21,87,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:14','2025-12-08 03:41:14'),(232,22,87,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:14','2025-12-08 03:41:14'),(233,23,87,'alert','amy@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:14','2025-12-08 03:41:14'),(234,8,88,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:24','2025-12-08 03:41:24'),(235,15,88,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:25','2025-12-08 03:41:25'),(236,18,88,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:25','2025-12-08 03:41:25'),(237,19,88,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:25','2025-12-08 03:41:25'),(238,20,88,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:25','2025-12-08 03:41:25'),(239,21,88,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:25','2025-12-08 03:41:25'),(240,22,88,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:26','2025-12-08 03:41:26'),(241,23,88,'alert','amy@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:26','2025-12-08 03:41:26'),(242,8,89,'alert','admin@cropalert.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:26','2025-12-08 03:41:26'),(243,15,89,'alert','alia@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:26','2025-12-08 03:41:26'),(244,18,89,'alert','mark@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:27','2025-12-08 03:41:27'),(245,19,89,'alert','mark46757@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:27','2025-12-08 03:41:27'),(246,20,89,'alert','markleonard.d.delrosario@isu.edu.ph','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:27','2025-12-08 03:41:27'),(247,21,89,'alert','markk@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:27','2025-12-08 03:41:27'),(248,22,89,'alert','lenard@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:27','2025-12-08 03:41:27'),(249,23,89,'alert','amy@gmail.com','Alert: forecast - Crop Alert System','failed','Email service not configured. Please configure SMTP settings (SMTP_USERNAME, SMTP_PASSWORD, SMTP_FROM_EMAIL) in config/config.php','2025-12-08 03:41:28','2025-12-08 03:41:28');
/*!40000 ALTER TABLE `email_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `encryption_keys`
--

DROP TABLE IF EXISTS `encryption_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `encryption_keys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key_name` varchar(100) NOT NULL,
  `key_value` varchar(255) NOT NULL COMMENT 'Base64 encoded key',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_name` (`key_name`),
  KEY `idx_encryption_keys_name` (`key_name`),
  KEY `idx_encryption_keys_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `encryption_keys`
--

LOCK TABLES `encryption_keys` WRITE;
/*!40000 ALTER TABLE `encryption_keys` DISABLE KEYS */;
INSERT INTO `encryption_keys` VALUES (1,'default_encryption_key','crop_alert_default_key_change_me_in_production','2025-11-29 13:39:18',NULL,1);
/*!40000 ALTER TABLE `encryption_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farmer_statistics_aggregates`
--

DROP TABLE IF EXISTS `farmer_statistics_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `farmer_statistics_aggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_date` date NOT NULL,
  `total_farmers` int(11) NOT NULL DEFAULT 0,
  `new_farmers_today` int(11) NOT NULL DEFAULT 0,
  `new_farmers_last_7_days` int(11) NOT NULL DEFAULT 0,
  `new_farmers_last_30_days` int(11) NOT NULL DEFAULT 0,
  `active_farmers_count` int(11) DEFAULT 0,
  `location_distribution` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`location_distribution`)),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_date` (`aggregate_date`),
  KEY `idx_aggregate_date` (`aggregate_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farmer_statistics_aggregates`
--

LOCK TABLES `farmer_statistics_aggregates` WRITE;
/*!40000 ALTER TABLE `farmer_statistics_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `farmer_statistics_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `farmers`
--

DROP TABLE IF EXISTS `farmers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `farmers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(150) NOT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `crops` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encrypted_contact` varchar(255) DEFAULT NULL COMMENT 'AES encrypted contact',
  PRIMARY KEY (`id`),
  KEY `idx_farmers_location` (`location`),
  KEY `idx_farmers_coordinates` (`latitude`,`longitude`),
  KEY `idx_farmers_name` (`name`),
  KEY `fk_farmers_location` (`location_id`),
  CONSTRAINT `fk_farmers_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `farmers`
--

LOCK TABLES `farmers` WRITE;
/*!40000 ALTER TABLE `farmers` DISABLE KEYS */;
/*!40000 ALTER TABLE `farmers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location_name` varchar(255) NOT NULL,
  `region` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `municipality` varchar(100) DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Philippines',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `location_name` (`location_name`),
  KEY `idx_locations_name` (`location_name`),
  KEY `idx_locations_region` (`region`),
  KEY `idx_locations_province` (`province`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'isabela',NULL,NULL,NULL,NULL,'Philippines','2025-12-02 12:42:28'),(2,'Manila',NULL,NULL,NULL,NULL,'Philippines','2025-12-02 12:42:28');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_history`
--

DROP TABLE IF EXISTS `login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT 'NULL for failed logins with invalid username',
  `username` varchar(50) NOT NULL COMMENT 'Username attempted (even if failed)',
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `logout_time` timestamp NULL DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `login_status` enum('success','failed','blocked') DEFAULT 'success',
  `failure_reason` varchar(255) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_login_history_user_id` (`user_id`),
  KEY `idx_login_history_login_time` (`login_time`),
  KEY `idx_login_history_status` (`login_status`),
  KEY `idx_login_history_ip` (`ip_address`),
  KEY `idx_login_history_user_time` (`user_id`,`login_time`),
  KEY `idx_login_history_session` (`session_id`),
  KEY `idx_login_history_user_status` (`user_id`,`login_status`,`login_time`),
  CONSTRAINT `login_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_history`
--

LOCK TABLES `login_history` WRITE;
/*!40000 ALTER TABLE `login_history` DISABLE KEYS */;
INSERT INTO `login_history` VALUES (1,7,'akii','2025-11-29 13:51:35',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'b9ddjd5aqrj4bt3mgm0mvbpiks','2025-11-29 13:51:35'),(2,5,'aki','2025-11-29 14:03:53',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'b9ddjd5aqrj4bt3mgm0mvbpiks','2025-11-29 14:03:53'),(3,15,'bisaya','2025-11-29 15:14:08',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'dk8sov5q6mefkgh6b6nub0eata','2025-11-29 15:14:08'),(4,5,'aki','2025-12-01 02:31:27',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ll6kq0l9imkueta4h379sdj7sd','2025-12-01 02:31:27'),(5,7,'akii','2025-12-01 02:31:56',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ll6kq0l9imkueta4h379sdj7sd','2025-12-01 02:31:56'),(6,18,'leon','2025-12-01 02:59:14',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ll6kq0l9imkueta4h379sdj7sd','2025-12-01 02:59:14'),(7,7,'akii','2025-12-01 03:02:34',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ll6kq0l9imkueta4h379sdj7sd','2025-12-01 03:02:34'),(8,21,'markiiee','2025-12-01 04:09:52',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'38fd6ncj4opbtgstqu39mvi19f','2025-12-01 04:09:52'),(9,7,'akii','2025-12-01 04:10:32',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'7648iq2jeveoab4ob6csnr6i2c','2025-12-01 04:10:32'),(10,21,'markiiee','2025-12-01 04:13:38',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'7648iq2jeveoab4ob6csnr6i2c','2025-12-01 04:13:38'),(11,5,'aki','2025-12-01 13:36:53',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'8rq229visos6j2lv8f0vrp17t0','2025-12-01 13:36:53'),(12,7,'akii','2025-12-01 13:37:47',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'8rq229visos6j2lv8f0vrp17t0','2025-12-01 13:37:47'),(13,7,'akii','2025-12-01 14:43:58',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'1f976nip4fj7dcothj9i7ribm0','2025-12-01 14:43:58'),(14,7,'akii','2025-12-01 15:21:40',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'vrmdgchq2gkbuj59uerh7jcrt0','2025-12-01 15:21:40'),(15,7,'akii','2025-12-01 15:35:09',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'vrmdgchq2gkbuj59uerh7jcrt0','2025-12-01 15:35:09'),(16,5,'aki','2025-12-01 16:20:20',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ov2ifgfl8h76lajcmqe11g8ck1','2025-12-01 16:20:20'),(17,7,'akii','2025-12-01 16:25:47',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ov2ifgfl8h76lajcmqe11g8ck1','2025-12-01 16:25:47'),(18,5,'aki','2025-12-01 16:27:33',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ov2ifgfl8h76lajcmqe11g8ck1','2025-12-01 16:27:33'),(19,11,'mark','2025-12-01 16:32:29',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','failed','Invalid username or password',NULL,'2025-12-01 16:32:29'),(20,15,'bisaya','2025-12-01 16:32:41',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ov2ifgfl8h76lajcmqe11g8ck1','2025-12-01 16:32:41'),(21,5,'aki','2025-12-01 16:33:31',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'ov2ifgfl8h76lajcmqe11g8ck1','2025-12-01 16:33:31'),(22,7,'akii','2025-12-03 03:55:11',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'fkki5ub2e5vhll4dti976igf8h','2025-12-03 03:55:11'),(23,7,'akii','2025-12-03 04:02:58',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'hq0c1os21dtaktkfot12g2lt44','2025-12-03 04:02:58'),(24,15,'bisaya','2025-12-03 07:15:41',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'o1td72emvbtj1ejb93ti2gh2jr','2025-12-03 07:15:41'),(25,5,'aki','2025-12-03 07:16:13',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'o1td72emvbtj1ejb93ti2gh2jr','2025-12-03 07:16:13'),(26,15,'alia','2025-12-03 07:30:02',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'o1td72emvbtj1ejb93ti2gh2jr','2025-12-03 07:30:02'),(27,7,'akii','2025-12-03 08:19:24',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'o1td72emvbtj1ejb93ti2gh2jr','2025-12-03 08:19:24'),(28,5,'aki','2025-12-03 09:06:12',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'o1td72emvbtj1ejb93ti2gh2jr','2025-12-03 09:06:12'),(29,5,'aki','2025-12-03 09:06:28',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'o1td72emvbtj1ejb93ti2gh2jr','2025-12-03 09:06:28'),(30,15,'alia','2025-12-03 09:07:43',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'o1td72emvbtj1ejb93ti2gh2jr','2025-12-03 09:07:43'),(31,5,'aki','2025-12-04 04:31:10',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'9nusulroscdnumgkm8v6jrsdce','2025-12-04 04:31:10'),(32,5,'aki','2025-12-04 04:47:20',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'9nusulroscdnumgkm8v6jrsdce','2025-12-04 04:47:20'),(33,5,'aki','2025-12-04 04:56:39',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'3qhg6i4c6pbir6ilnd8fma4q8v','2025-12-04 04:56:39'),(34,5,'aki','2025-12-04 10:23:41',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'cgs4ulqtgkuchn4uo6ctrips22','2025-12-04 10:23:41'),(35,7,'akii','2025-12-04 10:25:45',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'cgs4ulqtgkuchn4uo6ctrips22','2025-12-04 10:25:45'),(36,5,'aki','2025-12-07 07:30:09',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'b62mb1hvbfe4blm4liia6lh8mm','2025-12-07 07:30:09'),(37,7,'akii','2025-12-07 07:31:14',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'b62mb1hvbfe4blm4liia6lh8mm','2025-12-07 07:31:14'),(38,22,'lee','2025-12-07 07:34:43',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'b62mb1hvbfe4blm4liia6lh8mm','2025-12-07 07:34:43'),(39,5,'aki','2025-12-07 07:48:43',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'b62mb1hvbfe4blm4liia6lh8mm','2025-12-07 07:48:43'),(40,22,'lee','2025-12-07 07:49:37',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','success',NULL,'b62mb1hvbfe4blm4liia6lh8mm','2025-12-07 07:49:37'),(41,23,'amy','2025-12-08 02:29:36',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'sfq4kn81mqh4lhqt3our7gu86m','2025-12-08 02:29:36'),(42,5,'aki','2025-12-08 02:34:59',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'sfq4kn81mqh4lhqt3our7gu86m','2025-12-08 02:34:59'),(43,7,'akii','2025-12-08 02:49:58',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'sfq4kn81mqh4lhqt3our7gu86m','2025-12-08 02:49:58'),(44,5,'aki','2025-12-08 03:20:05',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'sfq4kn81mqh4lhqt3our7gu86m','2025-12-08 03:20:05'),(45,5,'aki','2025-12-08 06:07:36',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'sfq4kn81mqh4lhqt3our7gu86m','2025-12-08 06:07:36'),(46,5,'aki','2025-12-08 06:30:00',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'7he379g9pt05hegfh4gjglmail','2025-12-08 06:30:00'),(47,7,'akii','2025-12-08 06:45:22',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'7he379g9pt05hegfh4gjglmail','2025-12-08 06:45:22'),(48,5,'aki','2025-12-08 06:49:52',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'7he379g9pt05hegfh4gjglmail','2025-12-08 06:49:52'),(49,5,'aki','2025-12-08 23:19:14',NULL,'::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','success',NULL,'kkknh3brmokiqavrrv8u6cr26q','2025-12-08 23:19:14');
/*!40000 ALTER TABLE `login_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `market_demand_patterns`
--

DROP TABLE IF EXISTS `market_demand_patterns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `market_demand_patterns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crop_name` varchar(100) NOT NULL,
  `location` varchar(255) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `month` int(11) NOT NULL,
  `avg_demand_level` enum('very_low','low','medium','high','very_high') NOT NULL,
  `avg_price_multiplier` decimal(5,2) DEFAULT 1.00,
  `typical_supply_level` enum('very_low','low','medium','high','very_high') DEFAULT 'medium',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_demand_patterns_crop_month` (`crop_name`,`month`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_demand_patterns`
--

LOCK TABLES `market_demand_patterns` WRITE;
/*!40000 ALTER TABLE `market_demand_patterns` DISABLE KEYS */;
INSERT INTO `market_demand_patterns` VALUES (1,'Rice','Manila',NULL,1,'high',1.15,'medium',NULL),(2,'Rice','Manila',NULL,2,'high',1.20,'medium',NULL),(3,'Rice','Manila',NULL,3,'medium',1.00,'medium',NULL),(4,'Rice','Manila',NULL,4,'medium',0.95,'medium',NULL),(5,'Rice','Manila',NULL,5,'high',1.10,'medium',NULL),(6,'Rice','Manila',NULL,6,'very_high',1.25,'medium',NULL),(7,'Rice','Manila',NULL,7,'high',1.15,'medium',NULL),(8,'Rice','Manila',NULL,8,'medium',1.00,'medium',NULL),(9,'Rice','Manila',NULL,9,'medium',0.95,'medium',NULL),(10,'Rice','Manila',NULL,10,'high',1.10,'medium',NULL),(11,'Rice','Manila',NULL,11,'very_high',1.30,'medium',NULL),(12,'Rice','Manila',NULL,12,'very_high',1.35,'medium',NULL);
/*!40000 ALTER TABLE `market_demand_patterns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `market_prices`
--

DROP TABLE IF EXISTS `market_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `market_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crop_name` varchar(100) NOT NULL,
  `crop_type_id` int(11) DEFAULT NULL,
  `commodity_code` varchar(50) DEFAULT NULL,
  `price_per_kg` decimal(10,2) NOT NULL,
  `location` varchar(255) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `region_code` varchar(50) DEFAULT NULL,
  `market_name` varchar(255) DEFAULT NULL,
  `specification` varchar(255) DEFAULT NULL,
  `date` date NOT NULL,
  `quality_grade` enum('premium','standard','commercial') DEFAULT 'standard',
  `source` varchar(100) DEFAULT 'market_survey',
  `quality_score` decimal(3,2) DEFAULT NULL COMMENT 'Price quality score (0.00 to 1.00, higher is better)',
  `market_count` int(11) DEFAULT 1 COMMENT 'Number of markets sampled for this price',
  `price_range_min` decimal(10,2) DEFAULT NULL COMMENT 'Minimum price across markets',
  `price_range_max` decimal(10,2) DEFAULT NULL COMMENT 'Maximum price across markets',
  `is_verified` tinyint(1) DEFAULT 0,
  `verified_at` timestamp NULL DEFAULT NULL,
  `data_quality_score` decimal(3,2) DEFAULT 1.00,
  `volume_available` decimal(10,2) DEFAULT NULL,
  `demand_level` enum('very_low','low','medium','high','very_high') DEFAULT 'medium',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_market_prices_crop_date` (`crop_name`,`date`),
  KEY `idx_market_prices_location` (`location`),
  KEY `idx_market_prices_date` (`date`),
  KEY `idx_market_prices_market_location` (`market_name`,`location`),
  KEY `idx_market_prices_source` (`source`),
  KEY `idx_market_prices_region_code` (`region_code`),
  KEY `idx_market_prices_commodity_code` (`commodity_code`),
  KEY `idx_market_prices_crop_market_date` (`crop_name`,`market_name`,`date`),
  KEY `idx_market_prices_location_market_date` (`location`,`market_name`,`date`),
  KEY `idx_market_prices_composite` (`crop_name`,`location`,`date`,`source`),
  KEY `idx_market_prices_market_composite` (`market_name`,`crop_name`,`date`),
  KEY `idx_market_prices_quality` (`quality_score`),
  KEY `idx_market_prices_crop_location_source_date` (`crop_name`,`location`,`source`,`date`),
  CONSTRAINT `chk_price_positive` CHECK (`price_per_kg` > 0)
) ENGINE=InnoDB AUTO_INCREMENT=2447 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `market_prices`
--

LOCK TABLES `market_prices` WRITE;
/*!40000 ALTER TABLE `market_prices` DISABLE KEYS */;
INSERT INTO `market_prices` VALUES (1,'Rice',NULL,NULL,25.50,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','market_survey',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'high','2025-11-24 10:31:44'),(2,'Rice',NULL,NULL,24.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-23','standard','market_survey',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 10:31:44'),(3,'Rice',NULL,NULL,26.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-22','standard','market_survey',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'high','2025-11-24 10:31:44'),(4,'Corn',NULL,NULL,18.50,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','market_survey',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 10:31:44'),(5,'Tomato',NULL,NULL,35.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','market_survey',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'high','2025-11-24 10:31:44'),(6,'Eggplant',NULL,NULL,28.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','market_survey',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 10:31:44'),(7,'okra',NULL,NULL,25.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','calculated-seasonal-default',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 11:56:26'),(8,'okra',NULL,NULL,25.00,'isabela',NULL,NULL,NULL,NULL,'2025-11-24','standard','calculated-seasonal-default',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 11:56:26'),(9,'banana',NULL,NULL,25.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','calculated-seasonal-default',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 11:56:26'),(10,'banana',NULL,NULL,25.00,'isabela',NULL,NULL,NULL,NULL,'2025-11-24','standard','calculated-seasonal-default',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 11:56:26'),(11,'corn',NULL,NULL,25.00,'isabela',NULL,NULL,NULL,NULL,'2025-11-24','standard','calculated-seasonal-default',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 11:59:03'),(12,'mark',NULL,NULL,27.90,'Manila',NULL,NULL,NULL,NULL,'2025-10-26','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(13,'mark',NULL,NULL,27.57,'Manila',NULL,NULL,NULL,NULL,'2025-10-27','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(14,'mark',NULL,NULL,27.09,'Manila',NULL,NULL,NULL,NULL,'2025-10-28','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(15,'mark',NULL,NULL,27.03,'Manila',NULL,NULL,NULL,NULL,'2025-10-29','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(16,'mark',NULL,NULL,27.51,'Manila',NULL,NULL,NULL,NULL,'2025-10-30','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(17,'mark',NULL,NULL,32.01,'Manila',NULL,NULL,NULL,NULL,'2025-10-31','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(18,'mark',NULL,NULL,32.01,'Manila',NULL,NULL,NULL,NULL,'2025-11-01','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(19,'mark',NULL,NULL,28.41,'Manila',NULL,NULL,NULL,NULL,'2025-11-02','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(20,'mark',NULL,NULL,31.86,'Manila',NULL,NULL,NULL,NULL,'2025-11-03','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(21,'mark',NULL,NULL,31.83,'Manila',NULL,NULL,NULL,NULL,'2025-11-04','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(22,'mark',NULL,NULL,32.64,'Manila',NULL,NULL,NULL,NULL,'2025-11-05','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(23,'mark',NULL,NULL,31.62,'Manila',NULL,NULL,NULL,NULL,'2025-11-06','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(24,'mark',NULL,NULL,28.86,'Manila',NULL,NULL,NULL,NULL,'2025-11-07','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(25,'mark',NULL,NULL,28.86,'Manila',NULL,NULL,NULL,NULL,'2025-11-08','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(26,'mark',NULL,NULL,30.06,'Manila',NULL,NULL,NULL,NULL,'2025-11-09','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(27,'mark',NULL,NULL,32.76,'Manila',NULL,NULL,NULL,NULL,'2025-11-10','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(28,'mark',NULL,NULL,27.66,'Manila',NULL,NULL,NULL,NULL,'2025-11-11','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(29,'mark',NULL,NULL,29.61,'Manila',NULL,NULL,NULL,NULL,'2025-11-12','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(30,'mark',NULL,NULL,28.59,'Manila',NULL,NULL,NULL,NULL,'2025-11-13','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(31,'mark',NULL,NULL,30.09,'Manila',NULL,NULL,NULL,NULL,'2025-11-14','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(32,'mark',NULL,NULL,29.49,'Manila',NULL,NULL,NULL,NULL,'2025-11-15','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(33,'mark',NULL,NULL,29.61,'Manila',NULL,NULL,NULL,NULL,'2025-11-16','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(34,'mark',NULL,NULL,27.90,'Manila',NULL,NULL,NULL,NULL,'2025-11-17','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(35,'mark',NULL,NULL,28.53,'Manila',NULL,NULL,NULL,NULL,'2025-11-18','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(36,'mark',NULL,NULL,27.87,'Manila',NULL,NULL,NULL,NULL,'2025-11-19','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(37,'mark',NULL,NULL,30.81,'Manila',NULL,NULL,NULL,NULL,'2025-11-20','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(38,'mark',NULL,NULL,29.34,'Manila',NULL,NULL,NULL,NULL,'2025-11-21','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(39,'mark',NULL,NULL,29.10,'Manila',NULL,NULL,NULL,NULL,'2025-11-22','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(40,'mark',NULL,NULL,30.60,'Manila',NULL,NULL,NULL,NULL,'2025-11-23','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(41,'mark',NULL,NULL,30.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','calculated-seasonal-default',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 12:47:58'),(42,'okra',NULL,NULL,30.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 23:26:23'),(43,'okra',NULL,NULL,30.00,'isabela',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 23:26:24'),(44,'banana',NULL,NULL,30.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 23:26:24'),(45,'banana',NULL,NULL,30.00,'isabela',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 23:26:26'),(46,'corn',NULL,NULL,30.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 23:26:26'),(47,'corn',NULL,NULL,30.00,'isabela',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 23:26:27'),(48,'mark',NULL,NULL,30.07,'Manila',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-trend',0.51,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-24 23:35:34'),(49,'Rice',NULL,NULL,26.27,'Manila',NULL,NULL,NULL,NULL,'2025-11-25','standard','calculated-seasonal',0.47,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-25 00:10:34'),(50,'Banana',NULL,NULL,30.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-29','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:06:00'),(51,'Banana',NULL,NULL,30.00,'Isabela',NULL,NULL,NULL,NULL,'2025-11-29','standard','calculated-seasonal',0.47,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:06:02'),(52,'Corn',NULL,NULL,19.06,'Manila',NULL,NULL,NULL,NULL,'2025-11-29','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:06:06'),(53,'Corn',NULL,NULL,19.63,'Isabela',NULL,NULL,NULL,NULL,'2025-11-29','standard','calculated-seasonal',0.47,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:06:08'),(54,'Rice',NULL,NULL,27.06,'Manila',NULL,NULL,NULL,NULL,'2025-11-29','standard','calculated-seasonal',0.47,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:06:28'),(55,'Okra',NULL,NULL,33.00,'Manila',NULL,NULL,NULL,NULL,'2025-11-29','standard','calculated-seasonal-default',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:06:28'),(56,'Potato',NULL,NULL,33.92,'Manila',NULL,NULL,NULL,NULL,'2025-10-31','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(57,'Potato',NULL,NULL,36.33,'Manila',NULL,NULL,NULL,NULL,'2025-11-01','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(58,'Potato',NULL,NULL,35.91,'Manila',NULL,NULL,NULL,NULL,'2025-11-02','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(59,'Potato',NULL,NULL,32.80,'Manila',NULL,NULL,NULL,NULL,'2025-11-03','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(60,'Potato',NULL,NULL,38.40,'Manila',NULL,NULL,NULL,NULL,'2025-11-04','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(61,'Potato',NULL,NULL,35.28,'Manila',NULL,NULL,NULL,NULL,'2025-11-05','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(62,'Potato',NULL,NULL,37.87,'Manila',NULL,NULL,NULL,NULL,'2025-11-06','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(63,'Potato',NULL,NULL,34.30,'Manila',NULL,NULL,NULL,NULL,'2025-11-07','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(64,'Potato',NULL,NULL,32.87,'Manila',NULL,NULL,NULL,NULL,'2025-11-08','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(65,'Potato',NULL,NULL,33.43,'Manila',NULL,NULL,NULL,NULL,'2025-11-09','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(66,'Potato',NULL,NULL,36.61,'Manila',NULL,NULL,NULL,NULL,'2025-11-10','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(67,'Potato',NULL,NULL,33.36,'Manila',NULL,NULL,NULL,NULL,'2025-11-11','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(68,'Potato',NULL,NULL,34.20,'Manila',NULL,NULL,NULL,NULL,'2025-11-12','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(69,'Potato',NULL,NULL,33.18,'Manila',NULL,NULL,NULL,NULL,'2025-11-13','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(70,'Potato',NULL,NULL,35.53,'Manila',NULL,NULL,NULL,NULL,'2025-11-14','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(71,'Potato',NULL,NULL,35.35,'Manila',NULL,NULL,NULL,NULL,'2025-11-15','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(72,'Potato',NULL,NULL,33.25,'Manila',NULL,NULL,NULL,NULL,'2025-11-16','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(73,'Potato',NULL,NULL,33.18,'Manila',NULL,NULL,NULL,NULL,'2025-11-17','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(74,'Potato',NULL,NULL,34.55,'Manila',NULL,NULL,NULL,NULL,'2025-11-18','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(75,'Potato',NULL,NULL,37.42,'Manila',NULL,NULL,NULL,NULL,'2025-11-19','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(76,'Potato',NULL,NULL,36.58,'Manila',NULL,NULL,NULL,NULL,'2025-11-20','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(77,'Potato',NULL,NULL,35.88,'Manila',NULL,NULL,NULL,NULL,'2025-11-21','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(78,'Potato',NULL,NULL,38.22,'Manila',NULL,NULL,NULL,NULL,'2025-11-22','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(79,'Potato',NULL,NULL,33.29,'Manila',NULL,NULL,NULL,NULL,'2025-11-23','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(80,'Potato',NULL,NULL,34.48,'Manila',NULL,NULL,NULL,NULL,'2025-11-24','standard','seeded',0.34,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(81,'Potato',NULL,NULL,34.20,'Manila',NULL,NULL,NULL,NULL,'2025-11-25','standard','seeded',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(82,'Potato',NULL,NULL,36.68,'Manila',NULL,NULL,NULL,NULL,'2025-11-26','standard','seeded',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(83,'Potato',NULL,NULL,34.83,'Manila',NULL,NULL,NULL,NULL,'2025-11-27','standard','seeded',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(84,'Potato',NULL,NULL,34.79,'Manila',NULL,NULL,NULL,NULL,'2025-11-28','standard','seeded',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(85,'Potato',NULL,NULL,36.12,'Manila',NULL,NULL,NULL,NULL,'2025-11-29','standard','seeded',0.43,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-11-29 12:57:32'),(86,'Rice',NULL,NULL,28.41,'Manila',NULL,NULL,NULL,NULL,'2025-12-01','standard','calculated-seasonal',0.56,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-12-01 02:32:35'),(87,'Corn',NULL,NULL,20.01,'Manila',NULL,NULL,NULL,NULL,'2025-12-01','standard','calculated-seasonal',0.56,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-12-01 02:32:37'),(88,'Okra',NULL,NULL,35.64,'Manila',NULL,NULL,NULL,NULL,'2025-12-01','standard','calculated-seasonal',0.56,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-12-01 02:32:37'),(89,'Banana',NULL,NULL,30.00,'Manila',NULL,NULL,NULL,NULL,'2025-12-01','standard','calculated-seasonal',0.56,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-12-01 02:32:37'),(90,'Banana',NULL,NULL,30.00,'Isabela',NULL,NULL,NULL,NULL,'2025-12-01','standard','calculated-seasonal',0.56,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-12-01 02:33:59'),(91,'Corn',NULL,NULL,21.01,'Isabela',NULL,NULL,NULL,NULL,'2025-12-01','standard','calculated-seasonal',0.56,1,NULL,NULL,0,NULL,1.00,NULL,'medium','2025-12-01 02:34:02');
/*!40000 ALTER TABLE `market_prices` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_validate_price_positive
BEFORE INSERT ON market_prices
FOR EACH ROW
BEGIN
    IF NEW.price_per_kg <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Price must be greater than 0';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_validate_date_not_future
BEFORE INSERT ON market_prices
FOR EACH ROW
BEGIN
    IF NEW.date > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Date cannot be in the future';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_market_prices_after_insert
AFTER INSERT ON market_prices
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, new_values, created_at)
    VALUES (
        'market_prices',
        NEW.id,
        'INSERT',
        JSON_OBJECT(
            'crop_name', NEW.crop_name,
            'price_per_kg', NEW.price_per_kg,
            'location', NEW.location,
            'date', NEW.date
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER IF NOT EXISTS trg_update_price_quality_score
AFTER INSERT ON market_prices
FOR EACH ROW
BEGIN
    UPDATE market_prices
    SET data_quality_score = CASE
        WHEN source = 'bantay-presyo' THEN 1.00
        WHEN source LIKE 'api-%' THEN 0.85
        WHEN source = 'calculated' THEN 0.70
        WHEN source = 'market_survey' THEN 0.60
        ELSE 0.50
    END
    WHERE id = NEW.id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_validate_price_positive_update
BEFORE UPDATE ON market_prices
FOR EACH ROW
BEGIN
    IF NEW.price_per_kg <= 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Price must be greater than 0';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_validate_date_not_future_update
BEFORE UPDATE ON market_prices
FOR EACH ROW
BEGIN
    IF NEW.date > CURDATE() THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Date cannot be in the future';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `monthly_weather_aggregates`
--

DROP TABLE IF EXISTS `monthly_weather_aggregates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `monthly_weather_aggregates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `aggregate_year` int(11) NOT NULL,
  `aggregate_month` int(11) NOT NULL,
  `record_count` int(11) NOT NULL DEFAULT 0,
  `avg_temperature` decimal(5,2) DEFAULT NULL,
  `avg_humidity` decimal(5,2) DEFAULT NULL,
  `total_rainfall` decimal(10,2) DEFAULT 0.00,
  `avg_wind_speed` decimal(5,2) DEFAULT NULL,
  `condition_distribution` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`condition_distribution`)),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_year_month` (`aggregate_year`,`aggregate_month`),
  KEY `idx_year_month` (`aggregate_year`,`aggregate_month`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monthly_weather_aggregates`
--

LOCK TABLES `monthly_weather_aggregates` WRITE;
/*!40000 ALTER TABLE `monthly_weather_aggregates` DISABLE KEYS */;
/*!40000 ALTER TABLE `monthly_weather_aggregates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_forecasts`
--

DROP TABLE IF EXISTS `price_forecasts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `price_forecasts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crop_name` varchar(100) NOT NULL,
  `crop_type_id` int(11) DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `forecast_date` date NOT NULL,
  `predicted_price` decimal(10,2) NOT NULL,
  `confidence_level` decimal(5,2) DEFAULT NULL,
  `forecast_method` varchar(50) DEFAULT 'trend_analysis',
  `factors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`factors`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_price_forecasts_crop_date` (`crop_name`,`forecast_date`),
  KEY `idx_price_forecasts_location` (`location`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_forecasts`
--

LOCK TABLES `price_forecasts` WRITE;
/*!40000 ALTER TABLE `price_forecasts` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_forecasts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `storage_facilities`
--

DROP TABLE IF EXISTS `storage_facilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `storage_facilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `facility_type` enum('cold_storage','warehouse','silo','shed','none') DEFAULT 'none',
  `capacity_kg` decimal(10,2) NOT NULL,
  `current_storage_kg` decimal(10,2) DEFAULT 0.00,
  `cost_per_day_per_kg` decimal(10,4) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_storage_user_id` (`user_id`),
  CONSTRAINT `storage_facilities_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `storage_facilities`
--

LOCK TABLES `storage_facilities` WRITE;
/*!40000 ALTER TABLE `storage_facilities` DISABLE KEYS */;
/*!40000 ALTER TABLE `storage_facilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `value` varchar(1000) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`),
  KEY `idx_system_settings_category` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES (1,'email_notifications',NULL,'false','2025-11-08 08:55:42','2025-12-08 02:37:13'),(2,'sms_notifications',NULL,'false','2025-11-08 08:55:42','2025-12-08 02:37:13'),(3,'notification_frequency',NULL,'immediate','2025-11-08 08:55:42','2025-12-08 02:37:13'),(4,'data_retention_days',NULL,'90','2025-11-22 09:04:08','2025-11-22 09:04:08'),(5,'auto_backup_enabled',NULL,'true','2025-11-22 09:04:08','2025-11-22 09:04:08'),(6,'max_alerts_per_page',NULL,'50','2025-11-22 09:04:08','2025-11-22 09:04:08'),(7,'max_farmers_per_page',NULL,'100','2025-11-22 09:04:08','2025-11-22 09:04:08'),(8,'weather_api_key',NULL,'3G6B8WCJSMLKY53J4HUY6DNSN','2025-12-08 02:36:55','2025-12-08 02:36:55'),(9,'default_location',NULL,'Isabela, Philippines','2025-12-08 02:36:55','2025-12-08 02:36:55'),(10,'weather_update_interval',NULL,'30','2025-12-08 02:36:55','2025-12-08 02:36:55');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity_log`
--

DROP TABLE IF EXISTS `user_activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `activity_type` enum('login','dashboard_view','crop_add','alert_view','profile_update') NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user_activity_user_id` (`user_id`),
  KEY `idx_user_activity_created_at` (`created_at`),
  KEY `idx_user_activity_type` (`activity_type`),
  KEY `idx_user_activity_user_type` (`user_id`,`activity_type`),
  KEY `idx_user_activity_type_created` (`activity_type`,`created_at`),
  KEY `idx_user_activity_user_created` (`user_id`,`created_at`),
  CONSTRAINT `user_activity_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity_log`
--

LOCK TABLES `user_activity_log` WRITE;
/*!40000 ALTER TABLE `user_activity_log` DISABLE KEYS */;
INSERT INTO `user_activity_log` VALUES (1,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-29 13:51:35'),(2,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-29 14:03:53'),(3,15,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-29 15:14:08'),(4,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 02:31:27'),(5,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 02:31:56'),(6,18,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 02:59:14'),(7,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 03:02:34'),(8,21,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 04:09:52'),(9,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 04:10:32'),(10,21,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 04:13:38'),(11,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 13:36:53'),(12,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 13:37:47'),(13,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 14:43:58'),(14,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 15:21:40'),(15,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 15:35:09'),(16,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 16:20:20'),(17,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 16:25:47'),(18,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 16:27:33'),(19,15,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 16:32:41'),(20,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-01 16:33:31'),(21,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 03:55:11'),(22,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 04:02:58'),(23,15,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 07:15:41'),(24,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 07:16:13'),(25,15,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 07:30:02'),(26,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 08:19:24'),(27,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 09:06:12'),(28,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 09:06:28'),(29,15,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-03 09:07:43'),(30,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-04 04:31:10'),(31,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-04 04:47:20'),(32,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-04 04:56:39'),(33,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-04 10:23:41'),(34,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-04 10:25:45'),(35,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-07 07:30:09'),(36,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-07 07:31:14'),(37,22,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-07 07:34:43'),(38,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-07 07:48:43'),(39,22,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36','2025-12-07 07:49:37'),(40,23,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 02:29:36'),(41,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 02:34:59'),(42,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 02:49:58'),(43,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 03:20:05'),(44,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 06:07:36'),(45,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 06:30:00'),(46,7,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 06:45:22'),(47,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 06:49:52'),(48,5,'login','::1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-12-08 23:19:14');
/*!40000 ALTER TABLE `user_activity_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_crops`
--

DROP TABLE IF EXISTS `user_crops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_crops` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `crop_name` varchar(100) NOT NULL,
  `variety` varchar(50) DEFAULT NULL,
  `planting_date` date NOT NULL,
  `expected_harvest_date` date DEFAULT NULL,
  `area_hectares` decimal(8,2) NOT NULL,
  `status` enum('planted','growing','harvesting','harvested','failed') DEFAULT 'planted',
  `health_status` enum('excellent','good','fair','poor','critical') DEFAULT 'good',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `actual_harvest_date` date DEFAULT NULL,
  `actual_sell_date` date DEFAULT NULL,
  `sell_price_per_kg` decimal(10,2) DEFAULT NULL,
  `total_revenue` decimal(10,2) DEFAULT NULL,
  `storage_days` int(11) DEFAULT NULL,
  `market_timing_score` decimal(5,2) DEFAULT NULL,
  `expected_yield_kg` decimal(10,2) DEFAULT NULL,
  `crop_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_crops_user_id` (`user_id`),
  KEY `idx_user_crops_status` (`status`),
  KEY `idx_user_crops_planting_date` (`planting_date`),
  KEY `idx_user_crops_harvest_date` (`expected_harvest_date`),
  KEY `idx_user_crops_status_harvest` (`status`,`expected_harvest_date`),
  KEY `idx_user_crops_user_status_crop` (`user_id`,`status`,`crop_name`),
  KEY `idx_user_crops_crop_name` (`crop_name`),
  KEY `idx_user_crops_health_status` (`health_status`),
  KEY `fk_user_crops_crop_type` (`crop_type_id`),
  FULLTEXT KEY `ft_idx_user_crops_notes` (`notes`),
  CONSTRAINT `fk_user_crops_crop_type` FOREIGN KEY (`crop_type_id`) REFERENCES `crop_types` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_crops_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_crops`
--

LOCK TABLES `user_crops` WRITE;
/*!40000 ALTER TABLE `user_crops` DISABLE KEYS */;
INSERT INTO `user_crops` VALUES (3,7,'rice','grains','2025-01-20','2026-01-08',12.00,'planted','good','','2025-11-20 03:01:18','2025-12-01 13:40:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,7,'corn','corn','2025-11-24','2025-12-14',20.00,'planted','good','','2025-11-24 10:45:46','2025-11-24 11:58:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,7,'okra','vege','2025-09-16','2025-11-28',5.00,'planted','good','','2025-11-24 10:54:19','2025-11-24 10:57:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,7,'banana','fruit','2025-01-23','2025-12-30',1.00,'planted','good','','2025-11-24 10:59:52','2025-12-01 02:35:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,15,'potato','vege','2025-06-01','2026-01-01',3.00,'planted','good','','2025-11-29 12:57:18','2025-12-01 16:33:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,15,'rice','grains','2025-12-03','2026-09-30',15.00,'planted','good','','2025-12-03 09:08:22','2025-12-03 09:08:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_crops` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_user_crops_after_insert
AFTER INSERT ON user_crops
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, user_id, new_values, created_at)
    VALUES (
        'user_crops',
        NEW.id,
        'INSERT',
        NEW.user_id,
        JSON_OBJECT(
            'crop_name', NEW.crop_name,
            'planting_date', NEW.planting_date,
            'expected_harvest_date', NEW.expected_harvest_date,
            'area_hectares', NEW.area_hectares,
            'status', NEW.status
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_user_crops_after_update
AFTER UPDATE ON user_crops
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, user_id, old_values, new_values, created_at)
    VALUES (
        'user_crops',
        NEW.id,
        'UPDATE',
        NEW.user_id,
        JSON_OBJECT(
            'status', OLD.status,
            'health_status', OLD.health_status,
            'expected_harvest_date', OLD.expected_harvest_date
        ),
        JSON_OBJECT(
            'status', NEW.status,
            'health_status', NEW.health_status,
            'expected_harvest_date', NEW.expected_harvest_date
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','farmer') NOT NULL DEFAULT 'farmer',
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT 0,
  `email_verification_code` varchar(6) DEFAULT NULL,
  `email_verification_expires_at` timestamp NULL DEFAULT NULL,
  `email_verification_attempts` int(11) DEFAULT 0,
  `phone` varchar(20) DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `encrypted_email` varchar(255) DEFAULT NULL COMMENT 'AES encrypted email',
  `encrypted_phone` varchar(255) DEFAULT NULL COMMENT 'AES encrypted phone',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `idx_users_location` (`latitude`,`longitude`),
  KEY `idx_users_coordinates` (`latitude`,`longitude`),
  KEY `idx_users_role_created` (`role`,`created_at`),
  KEY `idx_users_role_location` (`role`,`location`(50)),
  KEY `idx_users_role_coordinates` (`role`,`latitude`,`longitude`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_is_active` (`is_active`),
  KEY `idx_users_role_active_created` (`role`,`is_active`,`created_at`),
  KEY `fk_users_location` (`location_id`),
  KEY `idx_users_verification_code` (`email_verification_code`),
  CONSTRAINT `fk_users_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (5,'aki','$2y$10$iOx6lj1e5uw9KFSGavrIHOnGBuWtgjrLv4eQm43jRZgLdZbLVRi5i','admin','mark',NULL,0,NULL,NULL,0,'','laguna','2025-11-17 09:12:07','2025-11-20 06:11:42',1,NULL,NULL,NULL,NULL,NULL),(7,'akii','$2y$10$mxPqtQB1nuIxXonqkTFdme32oo.XqXH/uNvTWRc5VEZQvGgQheepS','farmer','arkie','',0,NULL,NULL,0,'','isabela','2025-11-17 09:24:12','2025-11-25 10:17:36',1,16.73970383,121.69376000,NULL,NULL,NULL),(8,'leonard','$2y$10$296Mb20mcd7UM1qg97saXedk20py5eMJRHSJZaCVcof/o4HGMvvEy','admin','Leonard Admin','admin@cropalert.com',0,NULL,NULL,0,NULL,'Manila, Philippines','2025-11-20 03:06:14','2025-12-08 02:59:43',1,NULL,NULL,NULL,NULL,NULL),(9,'test','$2y$10$FvdFGsd5mT/mMPqHBXQT3O2BiWW20PGcuVLl51Lz.oU/Ldr7Hsxni','farmer','test',NULL,0,NULL,NULL,0,'','cebu','2025-11-20 04:40:54','2025-11-20 06:11:42',1,NULL,NULL,NULL,NULL,NULL),(10,'test2','$2y$10$rTxmchaIfmElBuDDHt7fYeH3046UcGbH6Fq55nq0lR1qzCkESIe7e','farmer','test2',NULL,0,NULL,NULL,0,'','laguna','2025-11-20 04:41:13','2025-11-20 06:11:42',1,NULL,NULL,NULL,NULL,NULL),(11,'mark','$2y$10$xXoHRsZ1ix4Hki54ISrGIOxTN59xkt8w50NreLucZLejgPv2uLxv6','farmer','mark',NULL,0,NULL,NULL,0,'','isabela','2025-11-20 04:41:31','2025-11-20 06:11:42',1,NULL,NULL,NULL,NULL,NULL),(12,'leo','$2y$10$iSzrwCx.VjzxUC75R8imL.a1V1N5oyscTBM.35d1wL3mjTidZft7K','farmer','leonard',NULL,0,NULL,NULL,0,'','isabela','2025-11-20 04:41:44','2025-11-20 06:11:42',1,NULL,NULL,NULL,NULL,NULL),(13,'zoro','$2y$10$y/pP1oCvMkwSSjybns/8uujXFXaSHAgkQvuwoLG09dI1j1WUKjjuq','farmer','zoro',NULL,0,NULL,NULL,0,'','echague','2025-11-20 04:42:04','2025-11-20 06:11:42',1,NULL,NULL,NULL,NULL,NULL),(15,'alia','$2y$10$yJ11sOB3BWBlTrjjVtRPnuaLzAvYOB.7nN/1ChrnCU1.tikiT1wHK','farmer','alia','alia@gmail.com',0,NULL,NULL,0,'','cebu','2025-11-25 01:23:33','2025-12-03 07:29:07',1,16.71927830,121.68763637,NULL,NULL,NULL),(18,'leon','$2y$10$9XNzLcheyVuALY7AsN.upelQu3N.T2ZWORInGqvH0XP2p2ofXwjRG','farmer','leonard','mark@gmail.com',0,NULL,NULL,0,'','pangasinan','2025-12-01 02:59:04','2025-12-01 02:59:04',1,NULL,NULL,NULL,NULL,NULL),(19,'arki','$2y$10$PJfpfDGN.4gkysr4WlKcmudraw1aRuctO.DEvVk4ZwySzIrrdyzbG','farmer','mark','mark46757@gmail.com',0,'$2y$10','2025-12-01 03:51:20',0,'','isabela','2025-12-01 03:36:20','2025-12-01 03:36:20',1,NULL,NULL,NULL,NULL,NULL),(20,'markk','$2y$10$qlNnJLKMGbhBXN60UmoCwehd0cvryizO0juaQ2fJX54WdG.4d8Ecm','farmer','mark','markleonard.d.delrosario@isu.edu.ph',0,'$2y$10','2025-12-01 04:19:24',0,'','isabela','2025-12-01 04:04:24','2025-12-01 04:04:24',1,NULL,NULL,NULL,NULL,NULL),(21,'markiiee','$2y$10$HjQ/U2q9nKQ8J1ds.M5Y3ekODa83CTw.ZieiOZCVftz7VbcQJDiwS','farmer','mark','markk@gmail.com',1,NULL,NULL,0,'','isabela','2025-12-01 04:09:42','2025-12-01 04:09:42',1,NULL,NULL,NULL,NULL,NULL),(22,'lee','$2y$10$GQMlhP1ggWvfzRoPej/hp.EzZoqwEJ5pxQkBEdboqpMD1.I0AcICG','farmer','leenard','lenard@gmail.com',1,NULL,NULL,0,'','echague','2025-12-07 07:34:34','2025-12-07 07:34:34',1,NULL,NULL,NULL,NULL,NULL),(23,'amy','$2y$10$d5FOAURV2cnlA.NH7.I3tesdGesLRqAmcvIEjlZPklkMa4l7zbb3O','farmer','amy','amy@gmail.com',1,NULL,NULL,0,'','echague','2025-12-08 02:29:24','2025-12-08 02:29:24',1,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_users_after_insert
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, user_id, username, new_values, created_at)
    VALUES (
        'users',
        NEW.id,
        'INSERT',
        NEW.id,
        NEW.username,
        JSON_OBJECT(
            'username', NEW.username,
            'role', NEW.role,
            'full_name', NEW.full_name,
            'email', NEW.email,
            'phone', NEW.phone,
            'location', NEW.location,
            'is_active', NEW.is_active
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_users_before_update
BEFORE UPDATE ON users
FOR EACH ROW
BEGIN
    SET NEW.updated_at = NOW();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_users_after_update
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, user_id, username, old_values, new_values, created_at)
    VALUES (
        'users',
        NEW.id,
        'UPDATE',
        NEW.id,
        NEW.username,
        JSON_OBJECT(
            'username', OLD.username,
            'role', OLD.role,
            'full_name', OLD.full_name,
            'email', OLD.email,
            'phone', OLD.phone,
            'location', OLD.location,
            'is_active', OLD.is_active
        ),
        JSON_OBJECT(
            'username', NEW.username,
            'role', NEW.role,
            'full_name', NEW.full_name,
            'email', NEW.email,
            'phone', NEW.phone,
            'location', NEW.location,
            'is_active', NEW.is_active
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_users_before_delete
BEFORE DELETE ON users
FOR EACH ROW
BEGIN
    IF OLD.role = 'admin' AND OLD.is_active = TRUE THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Cannot delete active admin user';
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER trg_users_after_delete
AFTER DELETE ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, username, old_values, created_at)
    VALUES (
        'users',
        OLD.id,
        'DELETE',
        OLD.username,
        JSON_OBJECT(
            'username', OLD.username,
            'role', OLD.role,
            'full_name', OLD.full_name,
            'email', OLD.email,
            'phone', OLD.phone,
            'location', OLD.location
        ),
        NOW()
    );
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `v_market_prices_aggregated`
--

DROP TABLE IF EXISTS `v_market_prices_aggregated`;
/*!50001 DROP VIEW IF EXISTS `v_market_prices_aggregated`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_market_prices_aggregated` AS SELECT
 1 AS `crop_name`,
  1 AS `location`,
  1 AS `date`,
  1 AS `avg_price_per_kg`,
  1 AS `min_price_per_kg`,
  1 AS `max_price_per_kg`,
  1 AS `market_count`,
  1 AS `markets`,
  1 AS `sources`,
  1 AS `has_bantay_presyo_data` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `v_price_trends_daily`
--

DROP TABLE IF EXISTS `v_price_trends_daily`;
/*!50001 DROP VIEW IF EXISTS `v_price_trends_daily`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `v_price_trends_daily` AS SELECT
 1 AS `crop_name`,
  1 AS `location`,
  1 AS `market_name`,
  1 AS `date`,
  1 AS `price_per_kg`,
  1 AS `source`,
  1 AS `specification`,
  1 AS `previous_price`,
  1 AS `price_change`,
  1 AS `price_change_percent`,
  1 AS `trend_direction` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_audit_summary`
--

DROP TABLE IF EXISTS `vw_audit_summary`;
/*!50001 DROP VIEW IF EXISTS `vw_audit_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_audit_summary` AS SELECT
 1 AS `table_name`,
  1 AS `action`,
  1 AS `audit_date`,
  1 AS `action_count`,
  1 AS `unique_users` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_login_summary`
--

DROP TABLE IF EXISTS `vw_login_summary`;
/*!50001 DROP VIEW IF EXISTS `vw_login_summary`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_login_summary` AS SELECT
 1 AS `login_date`,
  1 AS `total_logins`,
  1 AS `successful_logins`,
  1 AS `failed_logins`,
  1 AS `unique_users` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_users_public`
--

DROP TABLE IF EXISTS `vw_users_public`;
/*!50001 DROP VIEW IF EXISTS `vw_users_public`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_users_public` AS SELECT
 1 AS `id`,
  1 AS `username`,
  1 AS `role`,
  1 AS `full_name`,
  1 AS `location`,
  1 AS `latitude`,
  1 AS `longitude`,
  1 AS `created_at`,
  1 AS `is_active` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `weather_conditions`
--

DROP TABLE IF EXISTS `weather_conditions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weather_conditions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alert_id` int(11) NOT NULL,
  `temperature` decimal(5,2) DEFAULT NULL,
  `humidity` int(11) DEFAULT NULL,
  `rainfall` decimal(5,2) DEFAULT NULL,
  `wind_speed` decimal(5,2) DEFAULT NULL,
  `condition` varchar(100) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_weather_conditions_alert_recorded` (`alert_id`,`recorded_at`),
  KEY `idx_weather_conditions_recorded_at` (`recorded_at`),
  KEY `idx_weather_conditions_temperature` (`temperature`),
  CONSTRAINT `weather_conditions_ibfk_1` FOREIGN KEY (`alert_id`) REFERENCES `alerts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weather_conditions`
--

LOCK TABLES `weather_conditions` WRITE;
/*!40000 ALTER TABLE `weather_conditions` DISABLE KEYS */;
INSERT INTO `weather_conditions` VALUES (1,9,NULL,NULL,40.00,62.20,NULL,'2025-11-08 09:23:22'),(2,10,NULL,NULL,0.60,48.20,NULL,'2025-11-08 09:23:22'),(3,11,NULL,NULL,54.10,30.80,NULL,'2025-11-08 09:23:22'),(4,12,NULL,NULL,64.30,56.70,NULL,'2025-11-08 09:23:22'),(5,13,NULL,NULL,3.40,22.40,NULL,'2025-11-08 09:23:22'),(6,14,NULL,NULL,0.00,31.30,NULL,'2025-11-08 09:23:22'),(7,15,NULL,NULL,14.60,30.20,NULL,'2025-11-08 09:23:22'),(8,16,NULL,NULL,40.00,62.20,NULL,'2025-11-08 09:23:22'),(9,17,NULL,NULL,11.10,35.20,NULL,'2025-11-08 09:23:22'),(10,18,NULL,NULL,44.50,58.90,NULL,'2025-11-08 09:23:22'),(11,19,NULL,NULL,0.00,41.10,NULL,'2025-11-08 09:23:22'),(12,20,NULL,NULL,115.50,33.10,NULL,'2025-11-08 09:23:22'),(13,21,NULL,NULL,1.50,29.00,NULL,'2025-11-08 09:23:22'),(14,22,NULL,NULL,19.90,34.00,NULL,'2025-11-08 09:23:22'),(15,23,NULL,NULL,44.50,58.90,NULL,'2025-11-08 09:23:22'),(16,24,NULL,NULL,9.30,46.20,NULL,'2025-11-08 09:23:22'),(17,25,NULL,NULL,20.80,21.70,NULL,'2025-11-08 09:23:23'),(18,26,NULL,NULL,0.90,23.80,NULL,'2025-11-08 09:23:23'),(19,27,NULL,NULL,9.30,46.20,NULL,'2025-11-08 09:23:23'),(20,36,NULL,NULL,3.20,11.50,NULL,'2025-11-20 02:33:40'),(21,37,NULL,NULL,1.10,11.20,NULL,'2025-11-20 02:33:40'),(22,38,NULL,NULL,2.00,15.70,NULL,'2025-11-22 07:43:22'),(23,39,NULL,NULL,0.00,18.20,NULL,'2025-11-22 07:43:22'),(24,40,NULL,NULL,2.30,16.10,NULL,'2025-11-22 07:43:22'),(25,41,NULL,NULL,0.00,15.90,NULL,'2025-11-22 07:43:22'),(26,42,NULL,NULL,1.60,16.20,NULL,'2025-11-22 07:43:22'),(27,43,NULL,NULL,1.50,15.60,NULL,'2025-11-22 07:43:22'),(28,44,NULL,NULL,3.30,11.10,NULL,'2025-11-24 10:48:06'),(29,45,NULL,NULL,10.20,10.70,NULL,'2025-11-24 10:48:06');
/*!40000 ALTER TABLE `weather_conditions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weather_data`
--

DROP TABLE IF EXISTS `weather_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weather_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `temperature` decimal(5,2) NOT NULL,
  `humidity` int(11) NOT NULL,
  `rainfall` decimal(5,2) NOT NULL,
  `wind_speed` decimal(5,2) NOT NULL,
  `condition` varchar(100) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_weather_data_recorded_at` (`recorded_at`),
  KEY `idx_weather_data_recorded_condition` (`recorded_at`,`condition`),
  KEY `idx_weather_data_temp_humidity` (`temperature`,`humidity`),
  KEY `idx_weather_data_coordinates` (`latitude`,`longitude`),
  KEY `idx_weather_data_temperature` (`temperature`),
  KEY `idx_weather_data_recorded_temp_humidity` (`recorded_at`,`temperature`,`humidity`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weather_data`
--

LOCK TABLES `weather_data` WRITE;
/*!40000 ALTER TABLE `weather_data` DISABLE KEYS */;
INSERT INTO `weather_data` VALUES (1,28.50,65,15.20,12.30,'Partly Cloudy',NULL,NULL,'2025-11-08 07:57:29'),(2,30.20,70,8.50,8.70,'Sunny',NULL,NULL,'2025-11-08 07:57:29'),(3,26.80,75,25.40,15.20,'Rainy',NULL,NULL,'2025-11-08 07:57:29'),(4,32.10,60,2.10,6.80,'Sunny',NULL,NULL,'2025-11-08 07:57:29'),(5,24.50,80,35.60,18.90,'Stormy',NULL,NULL,'2025-11-08 07:57:29'),(6,31.00,80,10.00,6.00,'Rain Partly Cloudy',NULL,NULL,'2025-11-08 07:57:57'),(7,31.00,80,5.00,6.00,'Rain Partly Cloudy',NULL,NULL,'2025-11-08 07:58:13'),(8,31.00,80,15.00,6.00,'Rain Partly Cloudy',NULL,NULL,'2025-11-08 07:58:16'),(9,31.00,80,14.00,6.00,'Rain Partly Cloudy',NULL,NULL,'2025-11-08 07:58:19'),(10,31.00,80,13.00,6.00,'Rain Partly Cloudy',NULL,NULL,'2025-11-08 07:58:26'),(11,31.00,80,21.00,6.00,'Rain Partly Cloudy',NULL,NULL,'2025-11-08 07:59:12'),(12,31.00,80,16.00,6.00,'Rain Partly Cloudy',NULL,NULL,'2025-11-08 07:59:19'),(13,31.00,80,0.00,3.00,'Partly Cloudy',NULL,NULL,'2025-11-08 08:08:43'),(14,31.00,80,0.00,3.00,'Partly Cloudy',NULL,NULL,'2025-11-08 08:11:32'),(15,29.60,74,0.00,2.90,'Mainly Clear',NULL,NULL,'2025-11-17 09:27:55'),(16,29.30,71,0.00,22.60,'Overcast',NULL,NULL,'2025-11-22 08:25:17'),(17,27.50,78,0.00,20.50,'Slight Rain',NULL,NULL,'2025-11-25 01:22:24'),(18,27.40,84,0.00,21.30,'Overcast',NULL,NULL,'2025-11-25 10:18:14'),(19,29.40,79,0.00,12.20,'Overcast',NULL,NULL,'2025-11-26 09:34:33'),(20,29.40,79,0.00,12.20,'Overcast',NULL,NULL,'2025-11-26 09:34:49'),(21,27.90,82,0.40,5.10,'Thunderstorm',NULL,NULL,'2025-11-29 11:48:47'),(22,27.90,82,0.40,5.10,'Thunderstorm',NULL,NULL,'2025-11-29 11:53:30'),(23,27.80,82,0.60,5.10,'Thunderstorm with Hail',NULL,NULL,'2025-11-29 12:00:24'),(24,27.80,82,0.60,5.10,'Thunderstorm with Hail',NULL,NULL,'2025-11-29 12:01:50'),(25,27.80,82,0.60,5.00,'Thunderstorm with Hail',NULL,NULL,'2025-11-29 12:27:33'),(26,27.90,83,0.40,4.60,'Slight Rain Showers',NULL,NULL,'2025-11-29 13:48:38'),(27,27.90,83,0.40,4.60,'Slight Rain Showers',NULL,NULL,'2025-11-29 13:48:47'),(28,27.90,83,0.00,4.30,'Overcast',NULL,NULL,'2025-11-29 14:04:04'),(29,27.90,83,0.00,4.30,'Overcast',NULL,NULL,'2025-11-29 14:06:53'),(30,27.70,83,0.00,6.00,'Clear Sky',NULL,NULL,'2025-12-01 02:31:34'),(31,28.00,83,0.60,7.10,'Slight Rain Showers',NULL,NULL,'2025-12-01 13:37:03'),(32,27.60,86,0.10,5.10,'Thunderstorm',NULL,NULL,'2025-12-01 16:20:29'),(33,27.60,86,0.10,6.80,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:25:06'),(34,27.60,86,0.10,6.80,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:25:41'),(35,27.60,86,0.10,6.80,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:27:42'),(36,27.60,86,0.10,7.20,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:30:18'),(37,27.60,86,0.10,7.20,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:30:31'),(38,27.60,86,0.10,7.20,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:31:36'),(39,27.60,86,0.10,7.20,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:32:19'),(40,27.60,86,0.10,7.20,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:33:40'),(41,27.60,86,0.10,7.20,'Slight Rain Showers',NULL,NULL,'2025-12-01 16:33:58'),(42,28.80,79,0.00,6.90,'Mainly Clear',NULL,NULL,'2025-12-03 07:16:20'),(43,28.80,79,0.00,6.90,'Mainly Clear',NULL,NULL,'2025-12-03 07:22:46'),(44,28.80,79,0.00,6.90,'Mainly Clear',NULL,NULL,'2025-12-03 07:22:55'),(45,28.80,79,0.00,6.90,'Mainly Clear',NULL,NULL,'2025-12-03 07:23:28'),(46,28.80,79,0.00,6.90,'Mainly Clear',NULL,NULL,'2025-12-03 07:25:16'),(47,28.80,79,0.00,6.90,'Mainly Clear',NULL,NULL,'2025-12-03 07:27:05'),(48,28.80,79,0.00,6.90,'Mainly Clear',NULL,NULL,'2025-12-03 07:28:33'),(49,28.40,79,0.00,6.20,'Mainly Clear',NULL,NULL,'2025-12-03 09:06:37'),(50,30.00,65,17.00,11.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 04:32:30'),(51,29.90,57,0.00,30.00,'Mainly Clear',NULL,NULL,'2025-12-04 04:32:55'),(52,30.00,65,14.00,11.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 04:48:03'),(53,29.90,57,0.00,30.30,'Mainly Clear',NULL,NULL,'2025-12-04 04:48:10'),(54,29.90,57,0.00,30.30,'Mainly Clear',NULL,NULL,'2025-12-04 04:55:44'),(55,29.90,57,0.00,30.30,'Mainly Clear',NULL,NULL,'2025-12-04 04:55:49'),(56,29.90,57,0.00,30.30,'Mainly Clear',NULL,NULL,'2025-12-04 04:56:21'),(57,29.90,57,0.00,30.30,'Mainly Clear',NULL,NULL,'2025-12-04 04:57:15'),(58,30.00,65,12.00,11.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 04:57:32'),(59,29.90,57,0.00,30.60,'Mainly Clear',NULL,NULL,'2025-12-04 05:00:57'),(60,29.90,57,0.00,30.60,'Mainly Clear',NULL,NULL,'2025-12-04 05:02:10'),(61,29.90,57,0.00,30.60,'Mainly Clear',NULL,NULL,'2025-12-04 05:02:16'),(62,29.90,57,0.00,30.60,'Mainly Clear',NULL,NULL,'2025-12-04 05:03:17'),(63,29.90,57,0.00,30.60,'Mainly Clear',NULL,NULL,'2025-12-04 05:04:46'),(64,31.00,61,17.00,8.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 05:05:53'),(65,30.00,65,11.00,10.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 05:06:09'),(66,31.00,61,21.00,8.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 05:07:15'),(67,30.00,65,20.00,10.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 05:13:50'),(68,29.90,57,0.00,30.60,'Mainly Clear',NULL,NULL,'2025-12-04 05:14:00'),(69,30.00,65,18.00,10.00,'Rain Partly Cloudy',NULL,NULL,'2025-12-04 05:14:30'),(70,28.00,68,0.00,20.20,'Mainly Clear',NULL,NULL,'2025-12-04 10:23:49'),(71,27.20,76,0.00,18.20,'Overcast',NULL,NULL,'2025-12-07 07:30:16'),(72,27.20,76,0.00,18.20,'Overcast',NULL,NULL,'2025-12-07 07:30:56'),(73,27.30,76,0.00,18.40,'Overcast',NULL,NULL,'2025-12-07 07:48:49'),(74,27.40,76,0.00,18.40,'Overcast',NULL,NULL,'2025-12-07 08:01:48'),(75,27.90,79,0.00,10.90,'Overcast',NULL,NULL,'2025-12-08 02:35:06'),(76,28.00,78,0.00,11.30,'Overcast',NULL,NULL,'2025-12-08 02:48:38'),(77,28.40,77,0.00,11.60,'Overcast',NULL,NULL,'2025-12-08 03:20:12'),(78,28.40,77,0.00,11.60,'Overcast',NULL,NULL,'2025-12-08 03:27:52'),(79,28.60,75,0.00,11.40,'Overcast',NULL,NULL,'2025-12-08 03:41:11'),(80,28.60,75,0.00,11.40,'Overcast',NULL,NULL,'2025-12-08 03:41:23'),(81,28.90,74,0.00,13.10,'Overcast',NULL,NULL,'2025-12-08 04:50:17'),(82,29.30,71,0.00,13.80,'Overcast',NULL,NULL,'2025-12-08 06:07:43'),(83,29.30,71,0.00,14.70,'Overcast',NULL,NULL,'2025-12-08 06:30:08'),(84,29.30,71,0.00,14.70,'Overcast',NULL,NULL,'2025-12-08 06:30:22'),(85,27.50,80,0.00,4.80,'Overcast',NULL,NULL,'2025-12-08 23:19:24');
/*!40000 ALTER TABLE `weather_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'crop_alert_system'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_decrypt_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_decrypt_data`(p_encrypted_data VARCHAR(255), p_key VARCHAR(255)) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    READS SQL DATA
    DETERMINISTIC
BEGIN
    -- Get encryption key from encryption_keys table
    DECLARE v_key VARCHAR(255);
    SELECT key_value INTO v_key 
    FROM encryption_keys 
    WHERE key_name = p_key AND is_active = TRUE 
    LIMIT 1;
    
    IF v_key IS NULL THEN
        SET v_key = 'default_key_change_me'; -- Fallback key (should be changed)
    END IF;
    
    -- Return decrypted data (AES_DECRYPT)
    RETURN AES_DECRYPT(UNHEX(p_encrypted_data), v_key);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP FUNCTION IF EXISTS `fn_encrypt_data` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_encrypt_data`(p_data VARCHAR(255), p_key VARCHAR(255)) RETURNS varchar(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    READS SQL DATA
    DETERMINISTIC
BEGIN
    -- Get encryption key from encryption_keys table
    DECLARE v_key VARCHAR(255);
    SELECT key_value INTO v_key 
    FROM encryption_keys 
    WHERE key_name = p_key AND is_active = TRUE 
    LIMIT 1;
    
    IF v_key IS NULL THEN
        SET v_key = 'default_key_change_me'; -- Fallback key (should be changed)
    END IF;
    
    -- Return encrypted data (AES_ENCRYPT)
    RETURN HEX(AES_ENCRYPT(p_data, v_key));
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_disaster_with_areas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_disaster_with_areas`(
    IN p_name VARCHAR(255),
    IN p_type ENUM('typhoon', 'flood', 'drought', 'earthquake', 'pest_outbreak', 'disease_outbreak', 'other'),
    IN p_severity ENUM('low', 'medium', 'high', 'critical'),
    IN p_description TEXT,
    IN p_center_latitude DECIMAL(10, 8),
    IN p_center_longitude DECIMAL(11, 8),
    IN p_affected_radius_km DECIMAL(10, 2),
    OUT p_disaster_id INT,
    OUT p_status VARCHAR(50),
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_status = 'ERROR';
        SET p_message = 'Transaction failed: Disaster creation error';
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Insert disaster
    INSERT INTO disasters (name, type, severity, description, center_latitude, center_longitude, affected_radius_km)
    VALUES (p_name, p_type, p_severity, p_description, p_center_latitude, p_center_longitude, p_affected_radius_km);
    
    SET p_disaster_id = LAST_INSERT_ID();
    
    COMMIT;
    SET p_status = 'SUCCESS';
    SET p_message = 'Disaster created successfully';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_create_user_transaction` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_create_user_transaction`(
    IN p_username VARCHAR(50),
    IN p_password VARCHAR(255),
    IN p_role ENUM('admin', 'farmer'),
    IN p_full_name VARCHAR(100),
    IN p_email VARCHAR(100),
    IN p_phone VARCHAR(20),
    IN p_location VARCHAR(255),
    OUT p_user_id INT,
    OUT p_status VARCHAR(50),
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_status = 'ERROR';
        SET p_message = 'Transaction failed: User creation error';
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Check if username already exists
    IF EXISTS (SELECT 1 FROM users WHERE username = p_username) THEN
        ROLLBACK;
        SET p_status = 'ERROR';
        SET p_message = 'Username already exists';
    ELSE
        -- Insert user
        INSERT INTO users (username, password, role, full_name, email, phone, location)
        VALUES (p_username, p_password, p_role, p_full_name, p_email, p_phone, p_location);
        
        SET p_user_id = LAST_INSERT_ID();
        
        -- Log activity
        INSERT INTO user_activity_log (user_id, activity_type, created_at)
        VALUES (p_user_id, 'login', NOW());
        
        COMMIT;
        SET p_status = 'SUCCESS';
        SET p_message = 'User created successfully';
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_get_average_price` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_average_price`(
    IN p_crop_name VARCHAR(100),
    IN p_location VARCHAR(255),
    IN p_date DATE
)
BEGIN
    SELECT 
        crop_name,
        location,
        date,
        AVG(price_per_kg) AS avg_price,
        MIN(price_per_kg) AS min_price,
        MAX(price_per_kg) AS max_price,
        COUNT(*) AS market_count
    FROM market_prices
    WHERE crop_name = p_crop_name
      AND location = p_location
      AND date = p_date
    GROUP BY crop_name, location, date;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_get_latest_crop_prices` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_get_latest_crop_prices`(
    IN p_crop_name VARCHAR(100),
    IN p_location VARCHAR(255),
    IN p_days INT
)
BEGIN
    SELECT 
        mp.crop_name,
        mp.location,
        mp.market_name,
        mp.price_per_kg,
        mp.date,
        mp.source,
        mp.specification,
        mp.demand_level
    FROM market_prices mp
    WHERE mp.crop_name = p_crop_name
      AND mp.location = p_location
      AND mp.date >= DATE_SUB(CURDATE(), INTERVAL p_days DAY)
    ORDER BY mp.date DESC, mp.market_name;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_log_scraping` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_log_scraping`(
    IN p_region_code VARCHAR(50),
    IN p_commodity_code VARCHAR(50),
    IN p_scraping_date DATE,
    IN p_status VARCHAR(20),
    IN p_records_scraped INT,
    IN p_records_stored INT,
    IN p_error_message TEXT,
    IN p_execution_time DECIMAL(10,2)
)
BEGIN
    INSERT INTO bantay_presyo_scraping_log 
    (region_code, commodity_code, scraping_date, status, records_scraped, records_stored, error_message, execution_time_seconds, started_at, completed_at)
    VALUES 
    (p_region_code, p_commodity_code, p_scraping_date, p_status, p_records_scraped, p_records_stored, p_error_message, p_execution_time, NOW(), NOW())
    ON DUPLICATE KEY UPDATE
        status = VALUES(status),
        records_scraped = VALUES(records_scraped),
        records_stored = VALUES(records_stored),
        error_message = VALUES(error_message),
        execution_time_seconds = VALUES(execution_time_seconds),
        completed_at = NOW();
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_record_login` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_record_login`(
    IN p_user_id INT,
    IN p_username VARCHAR(50),
    IN p_ip_address VARCHAR(45),
    IN p_user_agent TEXT,
    IN p_login_status ENUM('success', 'failed', 'blocked'),
    IN p_failure_reason VARCHAR(255),
    IN p_session_id VARCHAR(255),
    OUT p_login_id INT,
    OUT p_status VARCHAR(50)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_status = 'ERROR';
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Insert login record
    INSERT INTO login_history (user_id, username, ip_address, user_agent, login_status, failure_reason, session_id)
    VALUES (p_user_id, p_username, p_ip_address, p_user_agent, p_login_status, p_failure_reason, p_session_id);
    
    SET p_login_id = LAST_INSERT_ID();
    
    -- Update user activity log
    IF p_login_status = 'success' THEN
        INSERT INTO user_activity_log (user_id, activity_type, ip_address, user_agent, created_at)
        VALUES (p_user_id, 'login', p_ip_address, p_user_agent, NOW());
    END IF;
    
    COMMIT;
    SET p_status = 'SUCCESS';
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_update_alert_status` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_update_alert_status`(
    IN p_alert_id INT,
    IN p_new_status ENUM('active', 'resolved', 'cancelled'),
    IN p_user_id INT,
    OUT p_status VARCHAR(50),
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SET p_status = 'ERROR';
        SET p_message = 'Transaction failed: Alert update error';
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Update alert status
    UPDATE alerts 
    SET status = p_new_status, updated_at = NOW()
    WHERE id = p_alert_id;

    IF ROW_COUNT() = 0 THEN
        ROLLBACK;
        SET p_status = 'ERROR';
        SET p_message = 'Alert not found';
    ELSE
        -- Log activity
        INSERT INTO user_activity_log (user_id, activity_type, created_at)
        VALUES (p_user_id, 'alert_view', NOW());
        
        COMMIT;
        SET p_status = 'SUCCESS';
        SET p_message = 'Alert status updated successfully';
    END IF;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_alert_statistics_aggregates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_alert_statistics_aggregates`(IN target_date DATE)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Calculate aggregates for the target date
    INSERT INTO alert_statistics_aggregates (
        aggregate_date,
        total_alerts,
        active_count,
        resolved_count,
        cancelled_count,
        type_distribution,
        severity_distribution,
        affected_farmers_count
    )
    SELECT 
        target_date,
        COALESCE(COUNT(*), 0) as total_alerts,
        COALESCE(SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END), 0) as active_count,
        COALESCE(SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END), 0) as resolved_count,
        COALESCE(SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END), 0) as cancelled_count,
        COALESCE((
            SELECT JSON_OBJECTAGG(COALESCE(type, 'unknown'), cnt)
            FROM (
                SELECT type, COUNT(*) as cnt
                FROM alerts
                WHERE DATE(created_at) = target_date
                GROUP BY type
            ) as type_sub
        ), JSON_OBJECT()) as type_distribution,
        COALESCE((
            SELECT JSON_OBJECTAGG(COALESCE(severity, 'unknown'), cnt)
            FROM (
                SELECT severity, COUNT(*) as cnt
                FROM alerts
                WHERE DATE(created_at) = target_date
                GROUP BY severity
            ) as severity_sub
        ), JSON_OBJECT()) as severity_distribution,
        COALESCE((
            SELECT COUNT(DISTINCT farmer_id) 
            FROM alert_farmers af
            INNER JOIN alerts a ON af.alert_id = a.id
            WHERE DATE(a.created_at) = target_date
        ), 0) as affected_farmers_count
    FROM alerts
    WHERE DATE(created_at) = target_date
    HAVING COUNT(*) > 0
    ON DUPLICATE KEY UPDATE
        total_alerts = VALUES(total_alerts),
        active_count = VALUES(active_count),
        resolved_count = VALUES(resolved_count),
        cancelled_count = VALUES(cancelled_count),
        type_distribution = VALUES(type_distribution),
        severity_distribution = VALUES(severity_distribution),
        affected_farmers_count = VALUES(affected_farmers_count),
        last_updated = CURRENT_TIMESTAMP;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_all_daily_aggregates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_all_daily_aggregates`()
BEGIN
    DECLARE target_date DATE DEFAULT CURDATE();
    
    CALL update_daily_weather_aggregates(target_date);
    CALL update_alert_statistics_aggregates(target_date);
    CALL update_farmer_statistics_aggregates(target_date);
    CALL update_crop_statistics_aggregates(target_date);
    CALL update_daily_user_statistics(target_date);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_crop_statistics_aggregates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_crop_statistics_aggregates`(IN target_date DATE)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Calculate aggregates for the target date
    INSERT INTO crop_statistics_aggregates (
        aggregate_date,
        total_crops,
        total_farmers_with_crops,
        crop_distribution,
        crop_by_status
    )
    SELECT 
        target_date,
        (SELECT COUNT(*) FROM user_crops) as total_crops,
        (SELECT COUNT(DISTINCT user_id) FROM user_crops) as total_farmers_with_crops,
        (SELECT JSON_OBJECTAGG(crop_name, crop_count)
         FROM (
             SELECT crop_name, COUNT(*) as crop_count
             FROM user_crops
             GROUP BY crop_name
             ORDER BY crop_count DESC
             LIMIT 10
         ) as crop_subquery) as crop_distribution,
        (SELECT JSON_OBJECTAGG(status, status_count)
         FROM (
             SELECT status, COUNT(*) as status_count
             FROM user_crops
             GROUP BY status
         ) as status_subquery) as crop_by_status
    ON DUPLICATE KEY UPDATE
        total_crops = VALUES(total_crops),
        total_farmers_with_crops = VALUES(total_farmers_with_crops),
        crop_distribution = VALUES(crop_distribution),
        crop_by_status = VALUES(crop_by_status),
        last_updated = CURRENT_TIMESTAMP;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_daily_user_statistics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_daily_user_statistics`(IN target_date DATE)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Calculate aggregates for the target date
    INSERT INTO daily_user_statistics (
        aggregate_date,
        total_users,
        total_farmers,
        total_admins,
        new_users_today,
        new_farmers_today,
        active_users_count,
        active_farmers_count
    )
    SELECT 
        target_date,
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM users WHERE role = 'farmer') as total_farmers,
        (SELECT COUNT(*) FROM users WHERE role = 'admin') as total_admins,
        (SELECT COUNT(*) FROM users WHERE DATE(created_at) = target_date) as new_users_today,
        (SELECT COUNT(*) FROM users 
         WHERE role = 'farmer' AND DATE(created_at) = target_date) as new_farmers_today,
        (SELECT COUNT(DISTINCT user_id) 
         FROM user_activity_log 
         WHERE created_at >= DATE_SUB(target_date, INTERVAL 7 DAY)) as active_users_count,
        (SELECT COUNT(DISTINCT af.farmer_id) 
         FROM alert_farmers af 
         INNER JOIN alerts a ON af.alert_id = a.id 
         WHERE a.created_at >= DATE_SUB(target_date, INTERVAL 7 DAY)) as active_farmers_count
    ON DUPLICATE KEY UPDATE
        total_users = VALUES(total_users),
        total_farmers = VALUES(total_farmers),
        total_admins = VALUES(total_admins),
        new_users_today = VALUES(new_users_today),
        new_farmers_today = VALUES(new_farmers_today),
        active_users_count = VALUES(active_users_count),
        active_farmers_count = VALUES(active_farmers_count),
        last_updated = CURRENT_TIMESTAMP;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_daily_weather_aggregates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_daily_weather_aggregates`(IN target_date DATE)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Calculate aggregates for the target date
    INSERT INTO daily_weather_aggregates (
        aggregate_date,
        record_count,
        avg_temperature,
        avg_humidity,
        total_rainfall,
        avg_wind_speed,
        condition_distribution
    )
    SELECT 
        target_date,
        COUNT(*) as record_count,
        AVG(temperature) as avg_temperature,
        AVG(humidity) as avg_humidity,
        SUM(rainfall) as total_rainfall,
        AVG(wind_speed) as avg_wind_speed,
        (SELECT JSON_OBJECTAGG(COALESCE(`condition`, 'unknown'), cnt)
         FROM (
             SELECT `condition`, COUNT(*) as cnt
             FROM weather_data
             WHERE DATE(recorded_at) = target_date
             GROUP BY `condition`
         ) as cond_sub) as condition_distribution
    FROM weather_data
    WHERE DATE(recorded_at) = target_date
    ON DUPLICATE KEY UPDATE
        record_count = VALUES(record_count),
        avg_temperature = VALUES(avg_temperature),
        avg_humidity = VALUES(avg_humidity),
        total_rainfall = VALUES(total_rainfall),
        avg_wind_speed = VALUES(avg_wind_speed),
        condition_distribution = VALUES(condition_distribution),
        last_updated = CURRENT_TIMESTAMP;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_farmer_statistics_aggregates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_farmer_statistics_aggregates`(IN target_date DATE)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Calculate aggregates for the target date
    INSERT INTO farmer_statistics_aggregates (
        aggregate_date,
        total_farmers,
        new_farmers_today,
        new_farmers_last_7_days,
        new_farmers_last_30_days,
        active_farmers_count,
        location_distribution
    )
    SELECT 
        target_date,
        (SELECT COUNT(*) FROM users WHERE role = 'farmer') as total_farmers,
        (SELECT COUNT(*) FROM users 
         WHERE role = 'farmer' AND DATE(created_at) = target_date) as new_farmers_today,
        (SELECT COUNT(*) FROM users 
         WHERE role = 'farmer' AND created_at >= DATE_SUB(target_date, INTERVAL 7 DAY)) as new_farmers_last_7_days,
        (SELECT COUNT(*) FROM users 
         WHERE role = 'farmer' AND created_at >= DATE_SUB(target_date, INTERVAL 30 DAY)) as new_farmers_last_30_days,
        (SELECT COUNT(DISTINCT af.farmer_id) 
         FROM alert_farmers af 
         INNER JOIN alerts a ON af.alert_id = a.id 
         WHERE a.created_at >= DATE_SUB(target_date, INTERVAL 30 DAY)) as active_farmers_count,
        (SELECT JSON_OBJECTAGG(location, location_count)
         FROM (
             SELECT location, COUNT(*) as location_count
             FROM users
             WHERE role = 'farmer' AND location IS NOT NULL AND location != ''
             GROUP BY location
             ORDER BY location_count DESC
             LIMIT 10
         ) as location_subquery) as location_distribution
    ON DUPLICATE KEY UPDATE
        total_farmers = VALUES(total_farmers),
        new_farmers_today = VALUES(new_farmers_today),
        new_farmers_last_7_days = VALUES(new_farmers_last_7_days),
        new_farmers_last_30_days = VALUES(new_farmers_last_30_days),
        active_farmers_count = VALUES(active_farmers_count),
        location_distribution = VALUES(location_distribution),
        last_updated = CURRENT_TIMESTAMP;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_monthly_weather_aggregates` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_monthly_weather_aggregates`(IN target_year INT, IN target_month INT)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- Calculate aggregates for the target month
    INSERT INTO monthly_weather_aggregates (
        aggregate_year,
        aggregate_month,
        record_count,
        avg_temperature,
        avg_humidity,
        total_rainfall,
        avg_wind_speed,
        condition_distribution
    )
    SELECT 
        target_year,
        target_month,
        COUNT(*) as record_count,
        AVG(temperature) as avg_temperature,
        AVG(humidity) as avg_humidity,
        SUM(rainfall) as total_rainfall,
        AVG(wind_speed) as avg_wind_speed,
        (SELECT JSON_OBJECTAGG(COALESCE(`condition`, 'unknown'), cnt)
         FROM (
             SELECT `condition`, COUNT(*) as cnt
             FROM weather_data
             WHERE YEAR(recorded_at) = target_year AND MONTH(recorded_at) = target_month
             GROUP BY `condition`
         ) as cond_sub) as condition_distribution
    FROM weather_data
    WHERE YEAR(recorded_at) = target_year AND MONTH(recorded_at) = target_month
    ON DUPLICATE KEY UPDATE
        record_count = VALUES(record_count),
        avg_temperature = VALUES(avg_temperature),
        avg_humidity = VALUES(avg_humidity),
        total_rainfall = VALUES(total_rainfall),
        avg_wind_speed = VALUES(avg_wind_speed),
        condition_distribution = VALUES(condition_distribution),
        last_updated = CURRENT_TIMESTAMP;
    
    COMMIT;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `v_market_prices_aggregated`
--

/*!50001 DROP VIEW IF EXISTS `v_market_prices_aggregated`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_market_prices_aggregated` AS select `market_prices`.`crop_name` AS `crop_name`,`market_prices`.`location` AS `location`,`market_prices`.`date` AS `date`,avg(`market_prices`.`price_per_kg`) AS `avg_price_per_kg`,min(`market_prices`.`price_per_kg`) AS `min_price_per_kg`,max(`market_prices`.`price_per_kg`) AS `max_price_per_kg`,count(0) AS `market_count`,group_concat(distinct `market_prices`.`market_name` order by `market_prices`.`market_name` ASC separator ', ') AS `markets`,group_concat(distinct `market_prices`.`source` order by `market_prices`.`source` ASC separator ', ') AS `sources`,max(case when `market_prices`.`source` = 'bantay-presyo' then 1 else 0 end) AS `has_bantay_presyo_data` from `market_prices` where `market_prices`.`date` >= curdate() - interval 90 day group by `market_prices`.`crop_name`,`market_prices`.`location`,`market_prices`.`date` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `v_price_trends_daily`
--

/*!50001 DROP VIEW IF EXISTS `v_price_trends_daily`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_price_trends_daily` AS select `mp1`.`crop_name` AS `crop_name`,`mp1`.`location` AS `location`,`mp1`.`market_name` AS `market_name`,`mp1`.`date` AS `date`,`mp1`.`price_per_kg` AS `price_per_kg`,`mp1`.`source` AS `source`,`mp1`.`specification` AS `specification`,`mp2`.`price_per_kg` AS `previous_price`,`mp1`.`price_per_kg` - `mp2`.`price_per_kg` AS `price_change`,case when `mp2`.`price_per_kg` > 0 then (`mp1`.`price_per_kg` - `mp2`.`price_per_kg`) / `mp2`.`price_per_kg` * 100 else NULL end AS `price_change_percent`,case when `mp1`.`price_per_kg` > `mp2`.`price_per_kg` then 'increasing' when `mp1`.`price_per_kg` < `mp2`.`price_per_kg` then 'decreasing' else 'stable' end AS `trend_direction` from (`market_prices` `mp1` left join `market_prices` `mp2` on(`mp1`.`crop_name` = `mp2`.`crop_name` and `mp1`.`location` = `mp2`.`location` and `mp1`.`market_name` = `mp2`.`market_name` and `mp2`.`date` = (select max(`mp3`.`date`) from `market_prices` `mp3` where `mp3`.`crop_name` = `mp1`.`crop_name` and `mp3`.`location` = `mp1`.`location` and `mp3`.`market_name` = `mp1`.`market_name` and `mp3`.`date` < `mp1`.`date`))) where `mp1`.`date` >= curdate() - interval 30 day order by `mp1`.`crop_name`,`mp1`.`location`,`mp1`.`market_name`,`mp1`.`date` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_audit_summary`
--

/*!50001 DROP VIEW IF EXISTS `vw_audit_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_audit_summary` AS select `audit_logs`.`table_name` AS `table_name`,`audit_logs`.`action` AS `action`,cast(`audit_logs`.`created_at` as date) AS `audit_date`,count(0) AS `action_count`,count(distinct `audit_logs`.`user_id`) AS `unique_users` from `audit_logs` group by `audit_logs`.`table_name`,`audit_logs`.`action`,cast(`audit_logs`.`created_at` as date) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_login_summary`
--

/*!50001 DROP VIEW IF EXISTS `vw_login_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_login_summary` AS select cast(`login_history`.`login_time` as date) AS `login_date`,count(0) AS `total_logins`,sum(case when `login_history`.`login_status` = 'success' then 1 else 0 end) AS `successful_logins`,sum(case when `login_history`.`login_status` = 'failed' then 1 else 0 end) AS `failed_logins`,count(distinct `login_history`.`user_id`) AS `unique_users` from `login_history` group by cast(`login_history`.`login_time` as date) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_users_public`
--

/*!50001 DROP VIEW IF EXISTS `vw_users_public`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_users_public` AS select `users`.`id` AS `id`,`users`.`username` AS `username`,`users`.`role` AS `role`,`users`.`full_name` AS `full_name`,`users`.`location` AS `location`,`users`.`latitude` AS `latitude`,`users`.`longitude` AS `longitude`,`users`.`created_at` AS `created_at`,`users`.`is_active` AS `is_active` from `users` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-09  7:19:27
